(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_sallery-list_sallery-list_module_ts"],{

/***/ 12142:
/*!*************************************************************!*\
  !*** ./src/app/sallery-list/sallery-list-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalleryListPageRoutingModule": () => (/* binding */ SalleryListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _sallery_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sallery-list.page */ 33966);




const routes = [
    {
        path: '',
        component: _sallery_list_page__WEBPACK_IMPORTED_MODULE_0__.SalleryListPage
    }
];
let SalleryListPageRoutingModule = class SalleryListPageRoutingModule {
};
SalleryListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SalleryListPageRoutingModule);



/***/ }),

/***/ 35493:
/*!*****************************************************!*\
  !*** ./src/app/sallery-list/sallery-list.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalleryListPageModule": () => (/* binding */ SalleryListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _sallery_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sallery-list-routing.module */ 12142);
/* harmony import */ var _sallery_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sallery-list.page */ 33966);







let SalleryListPageModule = class SalleryListPageModule {
};
SalleryListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _sallery_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.SalleryListPageRoutingModule
        ],
        declarations: [_sallery_list_page__WEBPACK_IMPORTED_MODULE_1__.SalleryListPage]
    })
], SalleryListPageModule);



/***/ }),

/***/ 33966:
/*!***************************************************!*\
  !*** ./src/app/sallery-list/sallery-list.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalleryListPage": () => (/* binding */ SalleryListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_sallery_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./sallery-list.page.html */ 34949);
/* harmony import */ var _sallery_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sallery-list.page.scss */ 88817);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 16274);




//import { Http, Headers, RequestOptions } from '@angular/http';









let SalleryListPage = class SalleryListPage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_amount = 0;
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.search_date = '';
        this.search_category = '';
        this.search_status = '';
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
            }
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ionViewWillEnter() {
        this.reloadDepositData();
    }
    ionViewDidEnter() {
        //  this.storage.clear();
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            yield loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_date": this.search_date,
                "search_status": this.search_status,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-sallery-transaction-getbyid', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    selectDate(dt) {
        this.search_date = this.datePipe.transform(dt, 'Y-MM-dd');
        // console.log(jj);
        this.reloadDepositData();
    }
    selectStatus(id) {
        this.search_status = id;
        //console.log(id);
        this.reloadDepositData();
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/return-request', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-single-edit', {
                index: i,
            }]);
    }
    remove_attendence(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            this.storage.forEach((value, key, index) => {
                                if (key == 'attendenceData') {
                                    value.forEach((val, key) => {
                                        if (key == id) {
                                            this.depositData.splice(key, 1);
                                            this.storage.remove(key).then((r) => {
                                                if (id == 0) {
                                                    this.storage.set("mintime", '');
                                                }
                                                else {
                                                    value.forEach((val2, key2) => {
                                                        if (key2 == (id - 1)) {
                                                            //console.log(val2.mintime);
                                                            this.storage.set("mintime", val2.mintime);
                                                        }
                                                    });
                                                }
                                                this.storage.set('attendenceData', this.depositData).then((r) => {
                                                    ;
                                                    this.reloadDepositData();
                                                    // this.storage.set("mintime",'06:30');
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
SalleryListPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__.DatePipe }
];
SalleryListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-sallery-list',
        template: _raw_loader_sallery_list_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_sallery_list_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SalleryListPage);



/***/ }),

/***/ 88817:
/*!*****************************************************!*\
  !*** ./src/app/sallery-list/sallery-list.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".list-header-md {\n  border-top: 0;\n}\n\n.segment-md .segment-button.activated,\n.segment-md .segment-button.segment-activated {\n  color: white;\n  border-color: #ffffff;\n  opacity: 1;\n  font-size: 14px;\n}\n\n.segment-md .segment-button {\n  color: white;\n  font-size: 14px;\n}\n\nion-segment-button.inner-segment.segment-button.segment-activated {\n  color: black;\n  border-color: black;\n}\n\nion-segment-button.inner-segment.segment-button {\n  color: lightgrey;\n  font-size: 14px;\n}\n\n.cs-header {\n  margin-bottom: 0;\n  background: white;\n  margin: 7px 0;\n  border-radius: 4px;\n}\n\n.checked {\n  color: green;\n}\n\n.cross {\n  color: red;\n}\n\n.backgrey {\n  background: rgba(0, 0, 0, 0.1);\n}\n\n.searchbar-md {\n  padding: 10px 0;\n}\n\n.cscard {\n  padding: 0;\n}\n\n.cscard .label-md {\n  margin: 0;\n}\n\n.cscard .item-md {\n  padding-left: 8px;\n}\n\n.cslist {\n  background: white;\n}\n\n.cslist .card-md {\n  margin: 0;\n  width: 100%;\n}\n\n.cslist .sc-ion-card-md-h {\n  margin-left: 0;\n  margin-right: 0;\n}\n\n.icon-big {\n  font-size: 1.6em;\n}\n\n.icon-right {\n  margin: 0;\n  padding: 0px;\n  line-height: 0;\n  float: right;\n}\n\n.back ion-item-sliding {\n  /*border: 1px solid #deeaff;*/\n  border-radius: 4px;\n  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 3px 1px -2px rgba(0, 0, 0, 0.12), 0 1px 5px 0 rgba(0, 0, 0, 0.2);\n}\n\n.list-md {\n  margin: 0px 0 12px;\n}\n\n.list-md ion-item-options {\n  border-bottom: none;\n}\n\n.forward-icon {\n  font-size: 2em;\n}\n\n.bordered-row {\n  border: 1px solid gainsboro;\n  padding: 7px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-slip {\n  border: 1px solid gainsboro;\n  padding: 1px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-blue-slip {\n  border: 1px solid #0091ea;\n  padding: 1px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-slip .label-md,\n.bordered-row-blue-slip .label-md {\n  margin: 3px 0px 3px 0;\n}\n\n.bordered-row-blue-slip .label-md,\n.bordered-row-blue-slip .text-input[disabled] {\n  color: #0091ea;\n}\n\n.bordered-row-blue-slip .item-button {\n  padding: 5px 8px;\n  height: auto;\n  font-size: 2.2rem;\n  box-shadow: none;\n}\n\n.back {\n  background: #f8f8f8;\n}\n\n.image_border {\n  border: 1px dashed lightgrey;\n  padding: 3px 3px 0px 3px;\n  border-radius: 6px;\n}\n\n.image_border img {\n  border-radius: 4px;\n  height: 35px;\n  width: 32px;\n}\n\n.list-title {\n  font-weight: 500;\n  color: #00364e;\n  font-size: 14px;\n}\n\n.list-title span {\n  color: #00b0ff;\n}\n\n.list-arrow {\n  color: #00b0ff;\n}\n\n.item-p {\n  color: #9e9e9e;\n}\n\n.pending-border {\n  border-left: 3px solid #ff0027;\n  margin-bottom: 12px;\n}\n\n.processing-border {\n  border-left: 3px solid #ffdc00;\n  margin-bottom: 12px;\n}\n\n.completed-border {\n  border-left: 3px solid #25e6c1;\n  margin-bottom: 12px;\n}\n\n.submitted-border {\n  border-left: 3px solid #00ab52;\n  margin-bottom: 12px;\n}\n\n.approved-border {\n  border-left: 3px solid #663399;\n  margin-bottom: 12px;\n}\n\n.back-grey {\n  background: #e8e8e8;\n  z-index: 9999999;\n}\n\nion-card-header {\n  font-weight: bold;\n}\n\n.nonet {\n  background: red;\n  color: white;\n  text-align: center;\n  width: 100%;\n  font-size: 14px;\n  z-index: 9999;\n}\n\n.smspan {\n  font-size: 12px;\n}\n\n.nomargin {\n  margin-top: 2px;\n  margin-bottom: 2px;\n}\n\n.shortmargin {\n  margin-right: 12px !important;\n}\n\n.margin {\n  margin-top: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNhbGxlcnktbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0FBQ0Y7O0FBRUE7O0VBRUUsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBQUVGOztBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQUdGOztBQURBO0VBQ0UsWUFBQTtBQUlGOztBQUZBO0VBQ0UsVUFBQTtBQUtGOztBQUhBO0VBQ0UsOEJBQUE7QUFNRjs7QUFKQTtFQUNFLGVBQUE7QUFPRjs7QUFMQTtFQUNFLFVBQUE7QUFRRjs7QUFOQTtFQUNFLFNBQUE7QUFTRjs7QUFQQTtFQUNFLGlCQUFBO0FBVUY7O0FBUkE7RUFDRSxpQkFBQTtBQVdGOztBQVRBO0VBQ0UsU0FBQTtFQUNBLFdBQUE7QUFZRjs7QUFWQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FBYUY7O0FBWEE7RUFDRSxnQkFBQTtBQWNGOztBQVpBO0VBQ0UsU0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQWVGOztBQWJBO0VBQ0UsNkJBQUE7RUFDQSxrQkFBQTtFQUVBLCtHQUFBO0FBZUY7O0FBWkE7RUFDRSxrQkFBQTtBQWVGOztBQWJBO0VBQ0UsbUJBQUE7QUFnQkY7O0FBZEE7RUFDRSxjQUFBO0FBaUJGOztBQWZBO0VBQ0UsMkJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQWtCRjs7QUFoQkE7RUFDRSwyQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBbUJGOztBQWpCQTtFQUNFLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFvQkY7O0FBbEJBOztFQUVFLHFCQUFBO0FBcUJGOztBQW5CQTs7RUFFRSxjQUFBO0FBc0JGOztBQXBCQTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUF1QkY7O0FBckJBO0VBQ0UsbUJBQUE7QUF3QkY7O0FBdEJBO0VBQ0UsNEJBQUE7RUFDQSx3QkFBQTtFQUNBLGtCQUFBO0FBeUJGOztBQXZCQTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUEwQkY7O0FBeEJBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQTJCRjs7QUF6QkE7RUFDRSxjQUFBO0FBNEJGOztBQTFCQTtFQUNFLGNBQUE7QUE2QkY7O0FBM0JBO0VBQ0UsY0FBQTtBQThCRjs7QUE1QkE7RUFDRSw4QkFBQTtFQUNBLG1CQUFBO0FBK0JGOztBQTdCQTtFQUNFLDhCQUFBO0VBQ0EsbUJBQUE7QUFnQ0Y7O0FBOUJBO0VBQ0UsOEJBQUE7RUFDQSxtQkFBQTtBQWlDRjs7QUEvQkE7RUFDRSw4QkFBQTtFQUNBLG1CQUFBO0FBa0NGOztBQWhDQTtFQUNFLDhCQUFBO0VBQ0EsbUJBQUE7QUFtQ0Y7O0FBakNBO0VBQ0UsbUJBQUE7RUFDQSxnQkFBQTtBQW9DRjs7QUFqQ0E7RUFDRSxpQkFBQTtBQW9DRjs7QUFsQ0E7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FBcUNGOztBQW5DQTtFQUNFLGVBQUE7QUFzQ0Y7O0FBcENBO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FBdUNGOztBQXJDQTtFQUNFLDZCQUFBO0FBd0NGOztBQXRDQTtFQUNFLGVBQUE7QUF5Q0YiLCJmaWxlIjoic2FsbGVyeS1saXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5saXN0LWhlYWRlci1tZCB7XHJcbiAgYm9yZGVyLXRvcDogMDtcclxufVxyXG5cclxuLnNlZ21lbnQtbWQgLnNlZ21lbnQtYnV0dG9uLmFjdGl2YXRlZCxcclxuLnNlZ21lbnQtbWQgLnNlZ21lbnQtYnV0dG9uLnNlZ21lbnQtYWN0aXZhdGVkIHtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgYm9yZGVyLWNvbG9yOiAjZmZmZmZmO1xyXG4gIG9wYWNpdHk6IDE7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG4uc2VnbWVudC1tZCAuc2VnbWVudC1idXR0b24ge1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuXHJcbmlvbi1zZWdtZW50LWJ1dHRvbi5pbm5lci1zZWdtZW50LnNlZ21lbnQtYnV0dG9uLnNlZ21lbnQtYWN0aXZhdGVkIHtcclxuICBjb2xvcjogYmxhY2s7XHJcbiAgYm9yZGVyLWNvbG9yOiBibGFjaztcclxufVxyXG5pb24tc2VnbWVudC1idXR0b24uaW5uZXItc2VnbWVudC5zZWdtZW50LWJ1dHRvbiB7XHJcbiAgY29sb3I6IGxpZ2h0Z3JleTtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuLmNzLWhlYWRlciB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMDtcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICBtYXJnaW46IDdweCAwO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxufVxyXG4uY2hlY2tlZCB7XHJcbiAgY29sb3I6IGdyZWVuO1xyXG59XHJcbi5jcm9zcyB7XHJcbiAgY29sb3I6IHJlZDtcclxufVxyXG4uYmFja2dyZXkge1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxufVxyXG4uc2VhcmNoYmFyLW1kIHtcclxuICBwYWRkaW5nOiAxMHB4IDA7XHJcbn1cclxuLmNzY2FyZCB7XHJcbiAgcGFkZGluZzogMDtcclxufVxyXG4uY3NjYXJkIC5sYWJlbC1tZCB7XHJcbiAgbWFyZ2luOiAwO1xyXG59XHJcbi5jc2NhcmQgLml0ZW0tbWQge1xyXG4gIHBhZGRpbmctbGVmdDogOHB4O1xyXG59XHJcbi5jc2xpc3Qge1xyXG4gIGJhY2tncm91bmQ6IHdoaXRlO1xyXG59XHJcbi5jc2xpc3QgLmNhcmQtbWQge1xyXG4gIG1hcmdpbjogMDtcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG4uY3NsaXN0IC5zYy1pb24tY2FyZC1tZC1oIHtcclxuICBtYXJnaW4tbGVmdDogMDtcclxuICBtYXJnaW4tcmlnaHQ6IDA7XHJcbn1cclxuLmljb24tYmlnIHtcclxuICBmb250LXNpemU6IDEuNmVtO1xyXG59XHJcbi5pY29uLXJpZ2h0IHtcclxuICBtYXJnaW46IDA7XHJcbiAgcGFkZGluZzogMHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAwO1xyXG4gIGZsb2F0OiByaWdodDtcclxufVxyXG4uYmFjayBpb24taXRlbS1zbGlkaW5nIHtcclxuICAvKmJvcmRlcjogMXB4IHNvbGlkICNkZWVhZmY7Ki9cclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgLy8gYm94LXNoYWRvdzogMXB4IDFweCA1cHggbGlnaHRncmV5O1xyXG4gIGJveC1zaGFkb3c6IDAgMnB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4xNCksXHJcbiAgICAwIDNweCAxcHggLTJweCByZ2JhKDAsIDAsIDAsIDAuMTIpLCAwIDFweCA1cHggMCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbn1cclxuLmxpc3QtbWQge1xyXG4gIG1hcmdpbjogMHB4IDAgMTJweDtcclxufVxyXG4ubGlzdC1tZCBpb24taXRlbS1vcHRpb25zIHtcclxuICBib3JkZXItYm90dG9tOiBub25lO1xyXG59XHJcbi5mb3J3YXJkLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogMmVtO1xyXG59XHJcbi5ib3JkZXJlZC1yb3cge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIGdhaW5zYm9ybztcclxuICBwYWRkaW5nOiA3cHggMDtcclxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxufVxyXG4uYm9yZGVyZWQtcm93LXNsaXAge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIGdhaW5zYm9ybztcclxuICBwYWRkaW5nOiAxcHggMDtcclxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxufVxyXG4uYm9yZGVyZWQtcm93LWJsdWUtc2xpcCB7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgIzAwOTFlYTtcclxuICBwYWRkaW5nOiAxcHggMDtcclxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxufVxyXG4uYm9yZGVyZWQtcm93LXNsaXAgLmxhYmVsLW1kLFxyXG4uYm9yZGVyZWQtcm93LWJsdWUtc2xpcCAubGFiZWwtbWQge1xyXG4gIG1hcmdpbjogM3B4IDBweCAzcHggMDtcclxufVxyXG4uYm9yZGVyZWQtcm93LWJsdWUtc2xpcCAubGFiZWwtbWQsXHJcbi5ib3JkZXJlZC1yb3ctYmx1ZS1zbGlwIC50ZXh0LWlucHV0W2Rpc2FibGVkXSB7XHJcbiAgY29sb3I6ICMwMDkxZWE7XHJcbn1cclxuLmJvcmRlcmVkLXJvdy1ibHVlLXNsaXAgLml0ZW0tYnV0dG9uIHtcclxuICBwYWRkaW5nOiA1cHggOHB4O1xyXG4gIGhlaWdodDogYXV0bztcclxuICBmb250LXNpemU6IDIuMnJlbTtcclxuICBib3gtc2hhZG93OiBub25lO1xyXG59XHJcbi5iYWNrIHtcclxuICBiYWNrZ3JvdW5kOiAjZjhmOGY4O1xyXG59XHJcbi5pbWFnZV9ib3JkZXIge1xyXG4gIGJvcmRlcjogMXB4IGRhc2hlZCBsaWdodGdyZXk7XHJcbiAgcGFkZGluZzogM3B4IDNweCAwcHggM3B4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDZweDtcclxufVxyXG4uaW1hZ2VfYm9yZGVyIGltZyB7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGhlaWdodDogMzVweDtcclxuICB3aWR0aDogMzJweDtcclxufVxyXG4ubGlzdC10aXRsZSB7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBjb2xvcjogIzAwMzY0ZTtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuLmxpc3QtdGl0bGUgc3BhbiB7XHJcbiAgY29sb3I6ICMwMGIwZmY7XHJcbn1cclxuLmxpc3QtYXJyb3cge1xyXG4gIGNvbG9yOiAjMDBiMGZmO1xyXG59XHJcbi5pdGVtLXAge1xyXG4gIGNvbG9yOiAjOWU5ZTllO1xyXG59XHJcbi5wZW5kaW5nLWJvcmRlciB7XHJcbiAgYm9yZGVyLWxlZnQ6IDNweCBzb2xpZCAjZmYwMDI3O1xyXG4gIG1hcmdpbi1ib3R0b206IDEycHg7XHJcbn1cclxuLnByb2Nlc3NpbmctYm9yZGVyIHtcclxuICBib3JkZXItbGVmdDogM3B4IHNvbGlkICNmZmRjMDA7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcclxufVxyXG4uY29tcGxldGVkLWJvcmRlciB7XHJcbiAgYm9yZGVyLWxlZnQ6IDNweCBzb2xpZCAjMjVlNmMxO1xyXG4gIG1hcmdpbi1ib3R0b206IDEycHg7XHJcbn1cclxuLnN1Ym1pdHRlZC1ib3JkZXIge1xyXG4gIGJvcmRlci1sZWZ0OiAzcHggc29saWQgIzAwYWI1MjtcclxuICBtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG59XHJcbi5hcHByb3ZlZC1ib3JkZXIge1xyXG4gIGJvcmRlci1sZWZ0OiAzcHggc29saWQgIzY2MzM5OTtcclxuICBtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG59XHJcbi5iYWNrLWdyZXkge1xyXG4gIGJhY2tncm91bmQ6ICNlOGU4ZTg7XHJcbiAgei1pbmRleDogOTk5OTk5OTtcclxufVxyXG5cclxuaW9uLWNhcmQtaGVhZGVyIHtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG4ubm9uZXQge1xyXG4gIGJhY2tncm91bmQ6IHJlZDtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICB6LWluZGV4OiA5OTk5O1xyXG59XHJcbi5zbXNwYW4ge1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxufVxyXG4ubm9tYXJnaW4ge1xyXG4gIG1hcmdpbi10b3A6IDJweDtcclxuICBtYXJnaW4tYm90dG9tOiAycHg7XHJcbn1cclxuLnNob3J0bWFyZ2luIHtcclxuICBtYXJnaW4tcmlnaHQ6IDEycHggIWltcG9ydGFudDtcclxufVxyXG4ubWFyZ2luIHtcclxuICBtYXJnaW4tdG9wOiA4cHg7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 34949:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sallery-list/sallery-list.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">My Sallery</ion-title>\n  </ion-toolbar>\n</ion-header> \n<ion-content>\n\n<ion-content>\n<form  (ngSubmit)=\"register(form)\">\n    <ion-grid>\n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <!-- <div text-center>\n            <h3>Create your account!</h3>\n          </div> -->\n          <ion-grid>\n            <!-- <ion-row>\n              <ion-col size=\"6\">\n                <ion-item-divider  color=\"light\">Total amount : <div> {{total_amount}}</div></ion-item-divider>\n                </ion-col>\n                <ion-col size=\"6\">\n                  \n                  <ion-button size=\"small\" color=\"primary\" (click)=\"gotorequestpage()\">Return Request</ion-button>\n                </ion-col>\n\n\n                </ion-row> -->\n\n                <ion-row color=\"primary\" justify-content-center>\n                  <ion-col align-self-center size=\"7\" >\n                  \n                   \n                    <ion-item>\n          \n                      <ion-label position=\"stacked\">Status</ion-label>\n                          \n                      <ion-select #S (ionChange)=\"selectStatus(S.value)\" interface=\"popover\" placeholder=\"Select status\" [(ngModel)]=\"search_status\" [ngModelOptions]=\"{standalone: true}\">\n                        <ion-select-option value=\"active\">Success</ion-select-option>\n                        <ion-select-option value=\"inactive\">Pending</ion-select-option>\n                       \n                      </ion-select>\n                        </ion-item>\n             </ion-col>\n             <ion-col align-self-center size=\"5\" >\n              <ion-item>\n              \n          <ion-label position=\"stacked\">Date</ion-label>\n              \n                 <ion-datetime #D (ionChange)=\"selectDate(D.value)\" placeholder=\"Date (D/M/Y)\" displayFormat=\"DD/MMM/YYYY\"  [(ngModel)]=\"search_date\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n              \n            </ion-item>\n    \n           \n            </ion-col>\n            </ion-row>\n           \n            <ion-row class=\"margin\">\n              <ion-col size=\"12\">\n                <div *ngFor=\"let inneritem of depositData; let i = index\">\n                  <ion-item-sliding #slidingItem1 class=\"submitted-border\">\n                    <ion-item lines=\"none\" color=\"grey\">\n                      <div slot=\"start\" class=\"shortmargin\">\n                        <h4>{{(i+1)}}</h4>\n                      </div>\n                      <ion-label class=\"nomargin\">  \n                          <ion-row>\n                            <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Amount: </span><br>{{inneritem.us_amount}}\n                              <!-- <span *ngIf=\"inneritem.uw_debit_credit=='dr'\" style=\"color: black;\">-Cr</span>\n                              <span *ngIf=\"inneritem.uw_debit_credit=='cr'\" style=\"color: black;\">-Dr</span> -->\n                              </h2>\n                            </ion-col>\n                            <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Status: </span><br>\n                                <ion-badge color=\"success\"  *ngIf=\"inneritem.us_status=='active'\">Success</ion-badge>\n                                <ion-badge color=\"warning\"  *ngIf=\"inneritem.us_status=='inactive'\">Pending</ion-badge>\n                              </h2>\n                            </ion-col>\n                            <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Date: </span><br>\n                                {{inneritem.us_pay_date | date:'MMM dd, yyyy'}}\n                              </h2>\n                            </ion-col>\n                            \n                          </ion-row>\n                          <!-- <ion-row>\n                            <ion-col size=\"12\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Reason: </span>\n                                {{inneritem.uw_description}}\n                              </h2>\n                              </ion-col>\n                              </ion-row> -->\n                        </ion-label>\n                       \n                    </ion-item>\n                  </ion-item-sliding>\n                </div>\n                <div *ngIf=\"!depositData.length\">\n\n                  <ion-row>\n                    <ion-col size=\"12\">\n   <h2 class=\"list-title\" style=\"font-size: 22px;color: #af1313;text-align: center; font-weight: 600;\"> No record found \n                       \n                      </h2>\n                      </ion-col>\n                      </ion-row>\n                </div>\n              </ion-col>\n              <!-- <ion-col size=\"12\" *ngIf=\"total_work_hrs<9\">\n                <div class=\"ion-text-center\">\n                <ion-button color=\"primary\" fill=\"outline\" (click)=\"addAttendence()\">\n                  <ion-icon slot=\"start\" name=\"add-circle-outline\"></ion-icon>\n                  Add Attendence\n                </ion-button>\n              </div>\n              </ion-col> -->\n            </ion-row>\n          </ion-grid>\n          <!-- <div padding *ngIf=\"total_work_hrs==9 && total_work_min==0\">\n            <ion-button  size=\"large\" (click)=\"openMenu()\"  expand=\"block\">Submit</ion-button>\n          </div>\n          <div padding *ngIf=\"total_work_hrs!=9\">\n            <ion-button  size=\"large\"  [disabled]=\"true\"  expand=\"block\">Submit</ion-button>\n          </div> -->\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    \n  </form>\n  \n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_sallery-list_sallery-list_module_ts.js.map