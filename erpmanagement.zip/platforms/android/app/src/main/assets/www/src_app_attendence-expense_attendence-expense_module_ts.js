(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_attendence-expense_attendence-expense_module_ts"],{

/***/ 58135:
/*!*************************************************************************!*\
  !*** ./src/app/attendence-expense/attendence-expense-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceExpensePageRoutingModule": () => (/* binding */ AttendenceExpensePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _attendence_expense_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence-expense.page */ 63672);




const routes = [
    {
        path: '',
        component: _attendence_expense_page__WEBPACK_IMPORTED_MODULE_0__.AttendenceExpensePage
    }
];
let AttendenceExpensePageRoutingModule = class AttendenceExpensePageRoutingModule {
};
AttendenceExpensePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AttendenceExpensePageRoutingModule);



/***/ }),

/***/ 94314:
/*!*****************************************************************!*\
  !*** ./src/app/attendence-expense/attendence-expense.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceExpensePageModule": () => (/* binding */ AttendenceExpensePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _attendence_expense_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence-expense-routing.module */ 58135);
/* harmony import */ var _attendence_expense_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence-expense.page */ 63672);







let AttendenceExpensePageModule = class AttendenceExpensePageModule {
};
AttendenceExpensePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _attendence_expense_routing_module__WEBPACK_IMPORTED_MODULE_0__.AttendenceExpensePageRoutingModule
        ],
        declarations: [_attendence_expense_page__WEBPACK_IMPORTED_MODULE_1__.AttendenceExpensePage]
    })
], AttendenceExpensePageModule);



/***/ }),

/***/ 63672:
/*!***************************************************************!*\
  !*** ./src/app/attendence-expense/attendence-expense.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceExpensePage": () => (/* binding */ AttendenceExpensePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_attendence_expense_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./attendence-expense.page.html */ 66968);
/* harmony import */ var _attendence_expense_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence-expense.page.scss */ 84557);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 16274);




//import { Http, Headers, RequestOptions } from '@angular/http';









let AttendenceExpensePage = class AttendenceExpensePage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.today = Date.now();
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_work_time = '';
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    submit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: 'Sending...'
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            if (this.name == '' && this.name == null) {
                this.alertController.create({
                    message: 'Enter name',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
                loading.dismiss();
            }
            else {
                yield loading.present();
                //var data ={}
                var data = {
                    "uwe_createdBy": this.userId,
                    "deposit_data": this.depositData,
                    //this.password
                };
                this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-work-expense-add', JSON.stringify(data), { headers: headers })
                    .subscribe((res) => {
                    // console.log(res);
                    loading.dismiss();
                    if (res.status == true) {
                        this.storage.remove("attendenceExpense");
                        this.depositData = [];
                        this.total_work_time = '';
                        this.reloadDepositData();
                        this.alertController.create({
                            message: 'Attendence successful',
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                    }
                    else {
                        this.alertController.create({
                            message: 'Something went wrong',
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                        loading.dismiss();
                    }
                }, (err) => {
                    //console.log(err);
                    loading.dismiss();
                });
            }
        });
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ionViewWillEnter() {
        // let gg=this.datePipe.transform(this.today, 'yyyy-MM-dd');
        // console.log(gg);
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
            }
            else {
                this.navCtrl.navigateForward('login');
            }
        });
    }
    ionViewDidEnter() {
        //  this.storage.clear();
        this.reloadDepositData();
    }
    edit_expense(id) {
        this.navCtrl.navigateForward(['/workexpense-edit', {
                id: id,
            }]);
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/workexpense-list', {
            // clientName: 'test',
            }]);
    }
    reloadDepositData2() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //let d
            // await this.storage.forEach( (value, key, index) => {
            //     if(key == 'attendenceExpense'){
            //       //console.log(value.length);
            //       this.depositData = value;
            //     }
            //   });
        });
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            yield loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_project": '',
                "search_date": this.datePipe.transform(this.today, 'yyyy-MM-dd'),
                "search_category": '',
                "search_status": '',
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-work-expense-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                }
                else {
                    this.depositData = res.response_data;
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    addAttendence() {
        this.navCtrl.navigateForward(['/attendence-expense-add', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-expense-edit', {
                index: i,
            }]);
    }
    remove_attendence(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            this.storage.forEach((value, key, index) => {
                                if (key == 'attendenceExpense') {
                                    value.forEach((val, key) => {
                                        if (key == id) {
                                            this.depositData.splice(key, 1);
                                            this.storage.remove(key).then((r) => {
                                                this.storage.set('attendenceExpense', this.depositData).then((r) => {
                                                    ;
                                                    this.reloadDepositData();
                                                    // this.storage.set("mintime",'06:30');
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    remove_expense(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    },
                    {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            loading.present();
                            let localarray = {
                                "userid": this.userId,
                                "id": id,
                                //"address":this.address,
                            };
                            //console.log(this.end_time);
                            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-work-expense-deletebyid', JSON.stringify(localarray), { headers: headers })
                                .subscribe((res) => {
                                // console.log(res);
                                loading.dismiss();
                                if (res.status == true) {
                                    this.reloadDepositData();
                                    this.alertController.create({
                                        message: 'Successfully deleted',
                                        buttons: ['OK']
                                    }).then(resalert => {
                                        resalert.present();
                                    });
                                }
                                else {
                                    this.alertController.create({
                                        message: 'Something went wrong',
                                        buttons: ['OK']
                                    }).then(resalert => {
                                        resalert.present();
                                    });
                                    loading.dismiss();
                                }
                            }, (err) => {
                                //console.log(err);
                                loading.dismiss();
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
AttendenceExpensePage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__.DatePipe }
];
AttendenceExpensePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-attendence-expense',
        template: _raw_loader_attendence_expense_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_attendence_expense_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AttendenceExpensePage);



/***/ }),

/***/ 84557:
/*!*****************************************************************!*\
  !*** ./src/app/attendence-expense/attendence-expense.page.scss ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhdHRlbmRlbmNlLWV4cGVuc2UucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ 66968:
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/attendence-expense/attendence-expense.page.html ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">Expense Module</ion-title>\n  </ion-toolbar>\n</ion-header> \n<ion-content>\n\n<ion-content>\n<form  (ngSubmit)=\"register(form)\">\n    <ion-grid>\n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <!-- <div text-center>\n            <h3>Create your account!</h3>\n          </div> -->\n          <ion-grid>\n             <ion-row>\n              <ion-col size=\"6\">\n               <ion-item-divider  color=\"light\">Today : <div> {{today |  date: ' dd-MMM-yyyy'}}</div></ion-item-divider>\n                </ion-col>\n                <ion-col size=\"6\">\n                  \n                  <ion-button size=\"small\" color=\"primary\" (click)=\"gotorequestpage()\">All Expense List</ion-button>\n                </ion-col>\n\n\n                </ion-row>\n            \n            <ion-row class=\"margin\">\n              <ion-col size=\"12\">\n                <div *ngFor=\"let inneritem of depositData; let i = index\">\n                  <ion-item-sliding #slidingItem1 class=\"submitted-border\">\n                    <ion-item lines=\"none\" color=\"grey\">\n                      <ion-label class=\"nomargin\">  \n                          <ion-row>\n                            <ion-col size=\"8\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Project: </span><br>{{inneritem.uwe_project}}</h2>\n                            </ion-col>\n                            <!-- <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Category: </span><br>{{inneritem.category_text}}</h2>\n                            </ion-col> -->\n                            <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Amount: </span><br>{{inneritem.uwe_amount}}</h2>\n                            </ion-col>\n                            \n                          </ion-row>\n                        </ion-label>\n                        <a  slot=\"end\" (click)=\"edit_expense(inneritem.uwe_id)\"> <ion-icon name=\"create-outline\"></ion-icon></a>\n                      <a style=\"margin-left: 22px;margin-right: -15px;\"  slot=\"end\" (click)=\"remove_expense(inneritem.uwe_id)\">  <ion-icon name=\"close-circle-outline\"></ion-icon></a>\n                    </ion-item>\n                  </ion-item-sliding>\n                </div>\n              </ion-col>\n              <ion-col size=\"12\" >\n                <div class=\"ion-text-center\">\n                <ion-button color=\"primary\" fill=\"outline\" (click)=\"addAttendence()\">\n                  <ion-icon slot=\"start\" name=\"add-circle-outline\"></ion-icon>\n                  Add Expense\n                </ion-button>\n              </div>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n          <!-- <div padding *ngIf=\"depositData.length\" >\n            <ion-button  size=\"large\" (click)=\"submit()\"  expand=\"block\">Submit</ion-button>\n          </div>\n          <div padding *ngIf=\"!depositData.length\">\n            <ion-button  size=\"large\"  [disabled]=\"true\"  expand=\"block\">Submit</ion-button>\n          </div> -->\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    \n  </form>\n  \n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_attendence-expense_attendence-expense_module_ts.js.map