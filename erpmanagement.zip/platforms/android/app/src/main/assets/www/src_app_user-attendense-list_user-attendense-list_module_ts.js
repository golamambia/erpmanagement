(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_user-attendense-list_user-attendense-list_module_ts"],{

/***/ 60029:
/*!*****************************************************************************!*\
  !*** ./src/app/user-attendense-list/user-attendense-list-routing.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserAttendenseListPageRoutingModule": () => (/* binding */ UserAttendenseListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _user_attendense_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-attendense-list.page */ 59832);




const routes = [
    {
        path: '',
        component: _user_attendense_list_page__WEBPACK_IMPORTED_MODULE_0__.UserAttendenseListPage
    }
];
let UserAttendenseListPageRoutingModule = class UserAttendenseListPageRoutingModule {
};
UserAttendenseListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserAttendenseListPageRoutingModule);



/***/ }),

/***/ 52746:
/*!*********************************************************************!*\
  !*** ./src/app/user-attendense-list/user-attendense-list.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserAttendenseListPageModule": () => (/* binding */ UserAttendenseListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _user_attendense_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-attendense-list-routing.module */ 60029);
/* harmony import */ var _user_attendense_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-attendense-list.page */ 59832);







let UserAttendenseListPageModule = class UserAttendenseListPageModule {
};
UserAttendenseListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _user_attendense_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserAttendenseListPageRoutingModule
        ],
        declarations: [_user_attendense_list_page__WEBPACK_IMPORTED_MODULE_1__.UserAttendenseListPage]
    })
], UserAttendenseListPageModule);



/***/ }),

/***/ 59832:
/*!*******************************************************************!*\
  !*** ./src/app/user-attendense-list/user-attendense-list.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserAttendenseListPage": () => (/* binding */ UserAttendenseListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_user_attendense_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./user-attendense-list.page.html */ 27790);
/* harmony import */ var _user_attendense_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-attendense-list.page.scss */ 62871);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 16274);




//import { Http, Headers, RequestOptions } from '@angular/http';









let UserAttendenseListPage = class UserAttendenseListPage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_amount = 0;
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.project_list = '';
        this.search_project = '';
        this.search_date = '';
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                this.getprojectList();
                this.reloadDepositData();
            }
        });
    }
    ionViewDidEnter() {
        //  this.storage.clear();
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            yield loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_project": this.search_project,
                "search_date": this.search_date,
                "checkout": ''
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-attendence-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getprojectList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-project-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.project_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    selectProject(id) {
        this.search_project = id;
        //console.log(id);
        this.reloadDepositData();
    }
    selectDate(dt) {
        this.search_date = this.datePipe.transform(dt, 'Y-MM-dd');
        // console.log(jj);
        this.reloadDepositData();
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/return-request', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-single-edit', {
                index: i,
            }]);
    }
};
UserAttendenseListPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__.DatePipe }
];
UserAttendenseListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-user-attendense-list',
        template: _raw_loader_user_attendense_list_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_user_attendense_list_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], UserAttendenseListPage);



/***/ }),

/***/ 62871:
/*!*********************************************************************!*\
  !*** ./src/app/user-attendense-list/user-attendense-list.page.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".list-header-md {\n  border-top: 0;\n}\n\n.segment-md .segment-button.activated,\n.segment-md .segment-button.segment-activated {\n  color: white;\n  border-color: #ffffff;\n  opacity: 1;\n  font-size: 14px;\n}\n\n.segment-md .segment-button {\n  color: white;\n  font-size: 14px;\n}\n\nion-segment-button.inner-segment.segment-button.segment-activated {\n  color: black;\n  border-color: black;\n}\n\nion-segment-button.inner-segment.segment-button {\n  color: lightgrey;\n  font-size: 14px;\n}\n\n.cs-header {\n  margin-bottom: 0;\n  background: white;\n  margin: 7px 0;\n  border-radius: 4px;\n}\n\n.checked {\n  color: green;\n}\n\n.cross {\n  color: red;\n}\n\n.backgrey {\n  background: rgba(0, 0, 0, 0.1);\n}\n\n.searchbar-md {\n  padding: 10px 0;\n}\n\n.cscard {\n  padding: 0;\n}\n\n.cscard .label-md {\n  margin: 0;\n}\n\n.cscard .item-md {\n  padding-left: 8px;\n}\n\n.cslist {\n  background: white;\n}\n\n.cslist .card-md {\n  margin: 0;\n  width: 100%;\n}\n\n.cslist .sc-ion-card-md-h {\n  margin-left: 0;\n  margin-right: 0;\n}\n\n.icon-big {\n  font-size: 1.6em;\n}\n\n.icon-right {\n  margin: 0;\n  padding: 0px;\n  line-height: 0;\n  float: right;\n}\n\n.back ion-item-sliding {\n  /*border: 1px solid #deeaff;*/\n  border-radius: 4px;\n  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 3px 1px -2px rgba(0, 0, 0, 0.12), 0 1px 5px 0 rgba(0, 0, 0, 0.2);\n}\n\n.list-md {\n  margin: 0px 0 12px;\n}\n\n.list-md ion-item-options {\n  border-bottom: none;\n}\n\n.forward-icon {\n  font-size: 2em;\n}\n\n.bordered-row {\n  border: 1px solid gainsboro;\n  padding: 7px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-slip {\n  border: 1px solid gainsboro;\n  padding: 1px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-blue-slip {\n  border: 1px solid #0091ea;\n  padding: 1px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-slip .label-md,\n.bordered-row-blue-slip .label-md {\n  margin: 3px 0px 3px 0;\n}\n\n.bordered-row-blue-slip .label-md,\n.bordered-row-blue-slip .text-input[disabled] {\n  color: #0091ea;\n}\n\n.bordered-row-blue-slip .item-button {\n  padding: 5px 8px;\n  height: auto;\n  font-size: 2.2rem;\n  box-shadow: none;\n}\n\n.back {\n  background: #f8f8f8;\n}\n\n.image_border {\n  border: 1px dashed lightgrey;\n  padding: 3px 3px 0px 3px;\n  border-radius: 6px;\n}\n\n.image_border img {\n  border-radius: 4px;\n  height: 35px;\n  width: 32px;\n}\n\n.list-title {\n  font-weight: 500;\n  color: #00364e;\n  font-size: 14px;\n}\n\n.list-title span {\n  color: #00b0ff;\n}\n\n.list-arrow {\n  color: #00b0ff;\n}\n\n.item-p {\n  color: #9e9e9e;\n}\n\n.pending-border {\n  border-left: 3px solid #ff0027;\n  margin-bottom: 12px;\n}\n\n.processing-border {\n  border-left: 3px solid #ffdc00;\n  margin-bottom: 12px;\n}\n\n.completed-border {\n  border-left: 3px solid #25e6c1;\n  margin-bottom: 12px;\n}\n\n.submitted-border {\n  border-left: 3px solid #00ab52;\n  margin-bottom: 12px;\n}\n\n.approved-border {\n  border-left: 3px solid #663399;\n  margin-bottom: 12px;\n}\n\n.back-grey {\n  background: #e8e8e8;\n  z-index: 9999999;\n}\n\nion-card-header {\n  font-weight: bold;\n}\n\n.nonet {\n  background: red;\n  color: white;\n  text-align: center;\n  width: 100%;\n  font-size: 14px;\n  z-index: 9999;\n}\n\n.smspan {\n  font-size: 12px;\n}\n\n.nomargin {\n  margin-top: 2px;\n  margin-bottom: 2px;\n}\n\n.shortmargin {\n  margin-right: 12px !important;\n}\n\n.margin {\n  margin-top: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItYXR0ZW5kZW5zZS1saXN0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7QUFDRjs7QUFFQTs7RUFFRSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQUE7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FBR0Y7O0FBREE7RUFDRSxZQUFBO0FBSUY7O0FBRkE7RUFDRSxVQUFBO0FBS0Y7O0FBSEE7RUFDRSw4QkFBQTtBQU1GOztBQUpBO0VBQ0UsZUFBQTtBQU9GOztBQUxBO0VBQ0UsVUFBQTtBQVFGOztBQU5BO0VBQ0UsU0FBQTtBQVNGOztBQVBBO0VBQ0UsaUJBQUE7QUFVRjs7QUFSQTtFQUNFLGlCQUFBO0FBV0Y7O0FBVEE7RUFDRSxTQUFBO0VBQ0EsV0FBQTtBQVlGOztBQVZBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUFhRjs7QUFYQTtFQUNFLGdCQUFBO0FBY0Y7O0FBWkE7RUFDRSxTQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FBZUY7O0FBYkE7RUFDRSw2QkFBQTtFQUNBLGtCQUFBO0VBRUEsK0dBQUE7QUFlRjs7QUFaQTtFQUNFLGtCQUFBO0FBZUY7O0FBYkE7RUFDRSxtQkFBQTtBQWdCRjs7QUFkQTtFQUNFLGNBQUE7QUFpQkY7O0FBZkE7RUFDRSwyQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBa0JGOztBQWhCQTtFQUNFLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFtQkY7O0FBakJBO0VBQ0UseUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQW9CRjs7QUFsQkE7O0VBRUUscUJBQUE7QUFxQkY7O0FBbkJBOztFQUVFLGNBQUE7QUFzQkY7O0FBcEJBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQXVCRjs7QUFyQkE7RUFDRSxtQkFBQTtBQXdCRjs7QUF0QkE7RUFDRSw0QkFBQTtFQUNBLHdCQUFBO0VBQ0Esa0JBQUE7QUF5QkY7O0FBdkJBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQTBCRjs7QUF4QkE7RUFDRSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBMkJGOztBQXpCQTtFQUNFLGNBQUE7QUE0QkY7O0FBMUJBO0VBQ0UsY0FBQTtBQTZCRjs7QUEzQkE7RUFDRSxjQUFBO0FBOEJGOztBQTVCQTtFQUNFLDhCQUFBO0VBQ0EsbUJBQUE7QUErQkY7O0FBN0JBO0VBQ0UsOEJBQUE7RUFDQSxtQkFBQTtBQWdDRjs7QUE5QkE7RUFDRSw4QkFBQTtFQUNBLG1CQUFBO0FBaUNGOztBQS9CQTtFQUNFLDhCQUFBO0VBQ0EsbUJBQUE7QUFrQ0Y7O0FBaENBO0VBQ0UsOEJBQUE7RUFDQSxtQkFBQTtBQW1DRjs7QUFqQ0E7RUFDRSxtQkFBQTtFQUNBLGdCQUFBO0FBb0NGOztBQWpDQTtFQUNFLGlCQUFBO0FBb0NGOztBQWxDQTtFQUNFLGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7QUFxQ0Y7O0FBbkNBO0VBQ0UsZUFBQTtBQXNDRjs7QUFwQ0E7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUF1Q0Y7O0FBckNBO0VBQ0UsNkJBQUE7QUF3Q0Y7O0FBdENBO0VBQ0UsZUFBQTtBQXlDRiIsImZpbGUiOiJ1c2VyLWF0dGVuZGVuc2UtbGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGlzdC1oZWFkZXItbWQge1xyXG4gIGJvcmRlci10b3A6IDA7XHJcbn1cclxuXHJcbi5zZWdtZW50LW1kIC5zZWdtZW50LWJ1dHRvbi5hY3RpdmF0ZWQsXHJcbi5zZWdtZW50LW1kIC5zZWdtZW50LWJ1dHRvbi5zZWdtZW50LWFjdGl2YXRlZCB7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGJvcmRlci1jb2xvcjogI2ZmZmZmZjtcclxuICBvcGFjaXR5OiAxO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLnNlZ21lbnQtbWQgLnNlZ21lbnQtYnV0dG9uIHtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG5pb24tc2VnbWVudC1idXR0b24uaW5uZXItc2VnbWVudC5zZWdtZW50LWJ1dHRvbi5zZWdtZW50LWFjdGl2YXRlZCB7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG4gIGJvcmRlci1jb2xvcjogYmxhY2s7XHJcbn1cclxuaW9uLXNlZ21lbnQtYnV0dG9uLmlubmVyLXNlZ21lbnQuc2VnbWVudC1idXR0b24ge1xyXG4gIGNvbG9yOiBsaWdodGdyZXk7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcbi5jcy1oZWFkZXIge1xyXG4gIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgbWFyZ2luOiA3cHggMDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbn1cclxuLmNoZWNrZWQge1xyXG4gIGNvbG9yOiBncmVlbjtcclxufVxyXG4uY3Jvc3Mge1xyXG4gIGNvbG9yOiByZWQ7XHJcbn1cclxuLmJhY2tncmV5IHtcclxuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbn1cclxuLnNlYXJjaGJhci1tZCB7XHJcbiAgcGFkZGluZzogMTBweCAwO1xyXG59XHJcbi5jc2NhcmQge1xyXG4gIHBhZGRpbmc6IDA7XHJcbn1cclxuLmNzY2FyZCAubGFiZWwtbWQge1xyXG4gIG1hcmdpbjogMDtcclxufVxyXG4uY3NjYXJkIC5pdGVtLW1kIHtcclxuICBwYWRkaW5nLWxlZnQ6IDhweDtcclxufVxyXG4uY3NsaXN0IHtcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxufVxyXG4uY3NsaXN0IC5jYXJkLW1kIHtcclxuICBtYXJnaW46IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuLmNzbGlzdCAuc2MtaW9uLWNhcmQtbWQtaCB7XHJcbiAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgbWFyZ2luLXJpZ2h0OiAwO1xyXG59XHJcbi5pY29uLWJpZyB7XHJcbiAgZm9udC1zaXplOiAxLjZlbTtcclxufVxyXG4uaWNvbi1yaWdodCB7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIHBhZGRpbmc6IDBweDtcclxuICBsaW5lLWhlaWdodDogMDtcclxuICBmbG9hdDogcmlnaHQ7XHJcbn1cclxuLmJhY2sgaW9uLWl0ZW0tc2xpZGluZyB7XHJcbiAgLypib3JkZXI6IDFweCBzb2xpZCAjZGVlYWZmOyovXHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIC8vIGJveC1zaGFkb3c6IDFweCAxcHggNXB4IGxpZ2h0Z3JleTtcclxuICBib3gtc2hhZG93OiAwIDJweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMTQpLFxyXG4gICAgMCAzcHggMXB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjEyKSwgMCAxcHggNXB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpO1xyXG59XHJcbi5saXN0LW1kIHtcclxuICBtYXJnaW46IDBweCAwIDEycHg7XHJcbn1cclxuLmxpc3QtbWQgaW9uLWl0ZW0tb3B0aW9ucyB7XHJcbiAgYm9yZGVyLWJvdHRvbTogbm9uZTtcclxufVxyXG4uZm9yd2FyZC1pY29uIHtcclxuICBmb250LXNpemU6IDJlbTtcclxufVxyXG4uYm9yZGVyZWQtcm93IHtcclxuICBib3JkZXI6IDFweCBzb2xpZCBnYWluc2Jvcm87XHJcbiAgcGFkZGluZzogN3B4IDA7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbn1cclxuLmJvcmRlcmVkLXJvdy1zbGlwIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCBnYWluc2Jvcm87XHJcbiAgcGFkZGluZzogMXB4IDA7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbn1cclxuLmJvcmRlcmVkLXJvdy1ibHVlLXNsaXAge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICMwMDkxZWE7XHJcbiAgcGFkZGluZzogMXB4IDA7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbn1cclxuLmJvcmRlcmVkLXJvdy1zbGlwIC5sYWJlbC1tZCxcclxuLmJvcmRlcmVkLXJvdy1ibHVlLXNsaXAgLmxhYmVsLW1kIHtcclxuICBtYXJnaW46IDNweCAwcHggM3B4IDA7XHJcbn1cclxuLmJvcmRlcmVkLXJvdy1ibHVlLXNsaXAgLmxhYmVsLW1kLFxyXG4uYm9yZGVyZWQtcm93LWJsdWUtc2xpcCAudGV4dC1pbnB1dFtkaXNhYmxlZF0ge1xyXG4gIGNvbG9yOiAjMDA5MWVhO1xyXG59XHJcbi5ib3JkZXJlZC1yb3ctYmx1ZS1zbGlwIC5pdGVtLWJ1dHRvbiB7XHJcbiAgcGFkZGluZzogNXB4IDhweDtcclxuICBoZWlnaHQ6IGF1dG87XHJcbiAgZm9udC1zaXplOiAyLjJyZW07XHJcbiAgYm94LXNoYWRvdzogbm9uZTtcclxufVxyXG4uYmFjayB7XHJcbiAgYmFja2dyb3VuZDogI2Y4ZjhmODtcclxufVxyXG4uaW1hZ2VfYm9yZGVyIHtcclxuICBib3JkZXI6IDFweCBkYXNoZWQgbGlnaHRncmV5O1xyXG4gIHBhZGRpbmc6IDNweCAzcHggMHB4IDNweDtcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbn1cclxuLmltYWdlX2JvcmRlciBpbWcge1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBoZWlnaHQ6IDM1cHg7XHJcbiAgd2lkdGg6IDMycHg7XHJcbn1cclxuLmxpc3QtdGl0bGUge1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgY29sb3I6ICMwMDM2NGU7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcbi5saXN0LXRpdGxlIHNwYW4ge1xyXG4gIGNvbG9yOiAjMDBiMGZmO1xyXG59XHJcbi5saXN0LWFycm93IHtcclxuICBjb2xvcjogIzAwYjBmZjtcclxufVxyXG4uaXRlbS1wIHtcclxuICBjb2xvcjogIzllOWU5ZTtcclxufVxyXG4ucGVuZGluZy1ib3JkZXIge1xyXG4gIGJvcmRlci1sZWZ0OiAzcHggc29saWQgI2ZmMDAyNztcclxuICBtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG59XHJcbi5wcm9jZXNzaW5nLWJvcmRlciB7XHJcbiAgYm9yZGVyLWxlZnQ6IDNweCBzb2xpZCAjZmZkYzAwO1xyXG4gIG1hcmdpbi1ib3R0b206IDEycHg7XHJcbn1cclxuLmNvbXBsZXRlZC1ib3JkZXIge1xyXG4gIGJvcmRlci1sZWZ0OiAzcHggc29saWQgIzI1ZTZjMTtcclxuICBtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG59XHJcbi5zdWJtaXR0ZWQtYm9yZGVyIHtcclxuICBib3JkZXItbGVmdDogM3B4IHNvbGlkICMwMGFiNTI7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcclxufVxyXG4uYXBwcm92ZWQtYm9yZGVyIHtcclxuICBib3JkZXItbGVmdDogM3B4IHNvbGlkICM2NjMzOTk7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcclxufVxyXG4uYmFjay1ncmV5IHtcclxuICBiYWNrZ3JvdW5kOiAjZThlOGU4O1xyXG4gIHotaW5kZXg6IDk5OTk5OTk7XHJcbn1cclxuXHJcbmlvbi1jYXJkLWhlYWRlciB7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuLm5vbmV0IHtcclxuICBiYWNrZ3JvdW5kOiByZWQ7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB3aWR0aDogMTAwJTtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgei1pbmRleDogOTk5OTtcclxufVxyXG4uc21zcGFuIHtcclxuICBmb250LXNpemU6IDEycHg7XHJcbn1cclxuLm5vbWFyZ2luIHtcclxuICBtYXJnaW4tdG9wOiAycHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMnB4O1xyXG59XHJcbi5zaG9ydG1hcmdpbiB7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMnB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuLm1hcmdpbiB7XHJcbiAgbWFyZ2luLXRvcDogOHB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 27790:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/user-attendense-list/user-attendense-list.page.html ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">My Attendance</ion-title>\n  </ion-toolbar>\n</ion-header> \n<ion-content>\n\n<ion-content>\n<form  (ngSubmit)=\"register(form)\">\n    <ion-grid>\n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <!-- <div text-center>\n            <h3>Create your account!</h3>\n          </div> -->\n          <ion-grid>\n            <ion-row color=\"primary\" justify-content-center>\n              <ion-col align-self-center size=\"7\" >\n              \n               \n                 <ion-item>\n          \n      <ion-label position=\"stacked\">Project</ion-label>\n          <ion-select #C (ionChange)=\"selectProject(C.value)\" interface=\"popover\" placeholder=\"Select project\" [(ngModel)]=\"search_project\" [ngModelOptions]=\"{standalone: true}\">\n            <ion-select-option *ngFor=\"let val of project_list; let i = index\" value=\"{{val.sub_project_id}}\">{{val.project_id}} > {{val.sub_project_id}}</ion-select-option>\n          </ion-select>\n        </ion-item> \n         </ion-col>\n         <ion-col align-self-center size=\"5\" >\n          <ion-item>\n          \n      <ion-label position=\"stacked\">Date</ion-label>\n          \n             <ion-datetime #D (ionChange)=\"selectDate(D.value)\" placeholder=\"Date (D/M/Y)\" displayFormat=\"DD/MMM/YYYY\"  [(ngModel)]=\"search_date\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n          \n        </ion-item>\n\n       \n        </ion-col>\n        </ion-row>\n\n\n\n\n\n           \n            <ion-row class=\"margin\">\n              <ion-col size=\"12\">\n                <div *ngFor=\"let inneritem of depositData; let i = index\">\n                  <ion-item-sliding #slidingItem1 class=\"submitted-border\">\n                    <ion-item lines=\"none\" color=\"grey\">\n                      <div slot=\"start\" class=\"shortmargin\">\n                        <h4>{{(i+1)}}</h4>\n                      </div>\n                      <ion-label class=\"nomargin\">  \n                        <ion-row>\n                          <ion-col size=\"6\">\n                            <h2 class=\"list-title\"><span class=\"smspan\">Time: </span><br>{{inneritem.ua_checkintime}} - {{inneritem.ua_checkouttime}}\n                           \n                            </h2>\n                          </ion-col>\n                          <ion-col size=\"6\">\n                            <h2 class=\"list-title\"><span class=\"smspan\"> Date: </span><br>\n                              {{inneritem.created_at | date:'MMM dd, yyyy'}}\n                            </h2>\n                          </ion-col>\n                        </ion-row>\n                          <ion-row>\n                            <ion-col size=\"6\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Project: </span><br>{{inneritem.ua_project}}\n                             \n                              </h2>\n                            </ion-col>\n                            <ion-col size=\"6\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Category: </span><br>\n                                {{inneritem.category_name}}\n                              </h2>\n                            </ion-col>\n                            \n                            \n                          </ion-row>\n                          <ion-row>\n                           \n                            <ion-col size=\"12\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Location In: </span><br>\n                                {{inneritem.ua_locationin}}\n                              </h2>\n                            </ion-col>\n                            <ion-col size=\"12\" >\n                              <h2 class=\"list-title\"><span class=\"smspan\">Location Out: </span><br>\n                                {{inneritem.ua_locationout}}\n                              </h2>\n                            </ion-col>\n                            \n                          </ion-row>\n                          <ion-row>\n                            <ion-col size=\"12\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Description: </span>\n                                {{inneritem.ua_description}}\n                              </h2>\n                              </ion-col>\n                              </ion-row>\n                        </ion-label>\n                       \n                    </ion-item>\n                  </ion-item-sliding>\n                </div>\n                <div *ngIf=\"!depositData.length\">\n\n                  <ion-row>\n                    <ion-col size=\"12\">\n   <h2 class=\"list-title\" style=\"font-size: 22px;color: #af1313;text-align: center; font-weight: 600;\"> No record found \n                       \n                      </h2>\n                      </ion-col>\n                      </ion-row>\n                </div>\n\n\n\n              </ion-col>\n              <!-- <ion-col size=\"12\" *ngIf=\"total_work_hrs<9\">\n                <div class=\"ion-text-center\">\n                <ion-button color=\"primary\" fill=\"outline\" (click)=\"addAttendence()\">\n                  <ion-icon slot=\"start\" name=\"add-circle-outline\"></ion-icon>\n                  Add Attendence\n                </ion-button>\n              </div>\n              </ion-col> -->\n            </ion-row>\n          </ion-grid>\n          <!-- <div padding *ngIf=\"total_work_hrs==9 && total_work_min==0\">\n            <ion-button  size=\"large\" (click)=\"openMenu()\"  expand=\"block\">Submit</ion-button>\n          </div>\n          <div padding *ngIf=\"total_work_hrs!=9\">\n            <ion-button  size=\"large\"  [disabled]=\"true\"  expand=\"block\">Submit</ion-button>\n          </div> -->\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    \n  </form>\n  \n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_user-attendense-list_user-attendense-list_module_ts.js.map