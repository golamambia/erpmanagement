(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_generale-leave_generale-leave_module_ts"],{

/***/ 86534:
/*!*****************************************************************!*\
  !*** ./src/app/generale-leave/generale-leave-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeneraleLeavePageRoutingModule": () => (/* binding */ GeneraleLeavePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _generale_leave_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generale-leave.page */ 18563);




const routes = [
    {
        path: '',
        component: _generale_leave_page__WEBPACK_IMPORTED_MODULE_0__.GeneraleLeavePage
    }
];
let GeneraleLeavePageRoutingModule = class GeneraleLeavePageRoutingModule {
};
GeneraleLeavePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GeneraleLeavePageRoutingModule);



/***/ }),

/***/ 99442:
/*!*********************************************************!*\
  !*** ./src/app/generale-leave/generale-leave.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeneraleLeavePageModule": () => (/* binding */ GeneraleLeavePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _generale_leave_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generale-leave-routing.module */ 86534);
/* harmony import */ var _generale_leave_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./generale-leave.page */ 18563);







let GeneraleLeavePageModule = class GeneraleLeavePageModule {
};
GeneraleLeavePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _generale_leave_routing_module__WEBPACK_IMPORTED_MODULE_0__.GeneraleLeavePageRoutingModule
        ],
        declarations: [_generale_leave_page__WEBPACK_IMPORTED_MODULE_1__.GeneraleLeavePage]
    })
], GeneraleLeavePageModule);



/***/ }),

/***/ 18563:
/*!*******************************************************!*\
  !*** ./src/app/generale-leave/generale-leave.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeneraleLeavePage": () => (/* binding */ GeneraleLeavePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_generale_leave_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./generale-leave.page.html */ 50857);
/* harmony import */ var _generale_leave_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./generale-leave.page.scss */ 96893);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser */ 93220);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 58361);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ 73181);
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ 71074);
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/camera/ngx */ 45103);
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ 41765);
/* harmony import */ var _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/base64/ngx */ 43170);




//import { Http, Headers, RequestOptions } from '@angular/http';

















let GeneraleLeavePage = class GeneraleLeavePage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, route, datePipe, nativeGeocoder, geolocation, camera, photoViewer, base64, sanitizer) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.route = route;
        this.datePipe = datePipe;
        this.nativeGeocoder = nativeGeocoder;
        this.geolocation = geolocation;
        this.camera = camera;
        this.photoViewer = photoViewer;
        this.base64 = base64;
        this.sanitizer = sanitizer;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.category = '';
        this.start_time = '';
        this.start_timenw = '';
        this.end_time = '';
        this.work_description = '';
        this.clientID = '';
        this.clientCode = '';
        this.newMin = '';
        this.address = '';
        this.current_address = '';
        this.expense_amount = '';
        this.depositImage = "";
        this.total_amount = 0;
        this.uw_mode = '';
        this.uw_txnno = '';
        this.modelist = '';
        this.leave_date = '';
        this.leave_description = '';
        this.total_leave = '';
        this.leave_no = '';
        this.leave_type = '';
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
            }
        });
        //this.clientID = this.route.snapshot.paramMap.get('clientName');
        // console.log(this.clientID);
        this.isToggled = false;
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        //this.storage.set("mintime",'09:30');
        //  this.storage.clear();s
    }
    ionViewWillEnter() {
        // this.getcashMode();
        this.getAmount();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    setMainTime() {
        // console.log(this.start_time);
        let tm = this.datePipe.transform(this.start_time, 'HH:mm');
        console.log(tm);
        this.start_timenw = moment__WEBPACK_IMPORTED_MODULE_4__(tm, "HH:mm").add(1, 'minutes').format('HH:mm');
        //console.log(this.start_timenw)
    }
    submit_mode() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Sending...'
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            if (!this.leave_type) {
                this.alertController.create({
                    message: 'Please select leave type',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            else if (!this.leave_date) {
                this.alertController.create({
                    message: 'Please select date',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            else if (!this.leave_description) {
                this.alertController.create({
                    message: 'Please enter reason',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            // else if(this.leave_no>this.total_leave.gen){
            //   this.alertController.create({
            //     message:'Please check leave no',
            //      buttons: ['OK']
            //    }).then(resalert => {
            //      resalert.present();
            //    });
            // }
            else {
                yield loading.present();
                var data = {
                    leave_type: this.leave_type,
                    leave_date: this.leave_date,
                    userId: this.userId,
                    leave_description: this.leave_description,
                    la_leave_type: 'gen',
                };
                this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-leave-application-create', JSON.stringify(data), { headers: headers })
                    .subscribe((res) => {
                    //console.log(res);
                    loading.dismiss();
                    if (res.status == true) {
                        this.leave_type = '';
                        this.leave_date = '';
                        this.leave_description = '';
                        this.getAmount();
                        this.alertController.create({
                            message: 'Request successful',
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                    }
                    else {
                        this.alertController.create({
                            message: 'Something went wrong',
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                        loading.dismiss();
                    }
                }, (err) => {
                    //console.log(err);
                    loading.dismiss();
                });
            }
        });
    }
    deposit_slip_image() {
        let options = {
            quality: 20,
            targetWidth: 768,
            targetHeight: 1360,
            // allowEdit: true,
            destinationType: this.camera.DestinationType.FILE_URI,
            sourceType: this.camera.PictureSourceType.CAMERA,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then(imageData => {
            this.base64.encodeFile(imageData).then((base64File) => {
                this.depositImage = base64File;
                // this.form.controls.ddImage = this.ddImage;				
            }, (err) => {
                //	this.showToastWithCloseButton("Image capture failed. Please try again.");
            });
        }, error => {
            console.log('ERROR -> ' + JSON.stringify(error));
        });
    }
    imageViewer(imageToView, text = '') {
        this.photoViewer.show(imageToView, text);
    }
    getAmount() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            //await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_date": '',
                "search_status": '',
                "leave_type": '',
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-leave-application-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.total_leave = res.total_leave;
                }
                else {
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getLocation() {
        this.geolocation.getCurrentPosition().then((resp) => {
            // resp.coords.latitude
            // resp.coords.longitude
            let options = {
                useLocale: true,
                maxResults: 5
            };
            this.nativeGeocoder.reverseGeocode(resp.coords.latitude, resp.coords.longitude, options)
                .then((result) => {
                // let data = {'pincode':result[0].postalCode, 'userId':10, 'type':'location', 'lat':this.latitude, 'lng': this.longitude}
                // console.log(result[0]);
                this.address = result[0].thoroughfare + ',' + result[0].postalCode + ',' + result[0].subAdministrativeArea
                    + ',' + result[0].administrativeArea + ',' + result[0].countryName;
            }).catch((error) => console.log(error));
        }).catch((error) => {
            console.log('Error getting location', error);
        });
    }
    getModeval(val) {
        //console.log(val);
    }
};
GeneraleLeavePage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_15__.DatePipe },
    { type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_5__.NativeGeocoder },
    { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_6__.Geolocation },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_7__.Camera },
    { type: _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__.PhotoViewer },
    { type: _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_9__.Base64 },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.DomSanitizer }
];
GeneraleLeavePage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.Component)({
        selector: 'app-generale-leave',
        template: _raw_loader_generale_leave_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_generale_leave_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], GeneraleLeavePage);



/***/ }),

/***/ 96893:
/*!*********************************************************!*\
  !*** ./src/app/generale-leave/generale-leave.page.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJnZW5lcmFsZS1sZWF2ZS5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ 50857:
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/generale-leave/generale-leave.page.html ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">Leave Request</ion-title>\n  </ion-toolbar>\n</ion-header> \n<ion-content>\n\n<ion-content>\n<form (ngSubmit)=\"register(form)\">\n    <ion-grid>\n      <ion-item-divider  color=\"light\">Total Generale Leave : <div>{{total_leave.gen}} </div></ion-item-divider>\n    \n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <!-- <div text-center>\n            <h3>Create your account!</h3>\n          </div> -->\n          <div padding>\n  \n  <ion-item>\n    <ion-label position=\"floating\">Leave type</ion-label>\n    \n    <ion-select  interface=\"popover\"  placeholder='Select type' [(ngModel)]=\"leave_type\" [ngModelOptions]=\"{standalone: true}\">\n      <ion-select-option  value=\"1sthalf\">1st Half</ion-select-option>\n      <ion-select-option  value=\"2ndhalf\">2nd Half</ion-select-option>\n      <ion-select-option  value=\"both\">Both</ion-select-option>\n    </ion-select>\n  \n  </ion-item>\n  <ion-item>\n  <ion-label position=\"stacked\">Date</ion-label>\n              \n                 <ion-datetime  placeholder=\"Date (D/M/Y)\" displayFormat=\"DD/MMM/YYYY\"  [(ngModel)]=\"leave_date\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n              \n            </ion-item>\n      \n  <ion-item>\n  <ion-label position=\"floating\">Reason</ion-label>\n  <ion-textarea placeholder=\"Enter here...\" [(ngModel)]=\"leave_description\" [ngModelOptions]=\"{standalone: true}\"></ion-textarea>\n</ion-item>\n\n\n  \n    \n<br>\n\n\n          </div>\n          <div padding>\n            <ion-button  size=\"large\" (click)=\"submit_mode()\"  expand=\"block\">Send</ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_generale-leave_generale-leave_module_ts.js.map