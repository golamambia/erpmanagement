(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_attendence-b-edit_attendence-b-edit_module_ts"],{

/***/ 70359:
/*!***********************************************************************!*\
  !*** ./src/app/attendence-b-edit/attendence-b-edit-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceBEditPageRoutingModule": () => (/* binding */ AttendenceBEditPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _attendence_b_edit_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence-b-edit.page */ 26319);




const routes = [
    {
        path: '',
        component: _attendence_b_edit_page__WEBPACK_IMPORTED_MODULE_0__.AttendenceBEditPage
    }
];
let AttendenceBEditPageRoutingModule = class AttendenceBEditPageRoutingModule {
};
AttendenceBEditPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AttendenceBEditPageRoutingModule);



/***/ }),

/***/ 6514:
/*!***************************************************************!*\
  !*** ./src/app/attendence-b-edit/attendence-b-edit.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceBEditPageModule": () => (/* binding */ AttendenceBEditPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _attendence_b_edit_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence-b-edit-routing.module */ 70359);
/* harmony import */ var _attendence_b_edit_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence-b-edit.page */ 26319);







let AttendenceBEditPageModule = class AttendenceBEditPageModule {
};
AttendenceBEditPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _attendence_b_edit_routing_module__WEBPACK_IMPORTED_MODULE_0__.AttendenceBEditPageRoutingModule
        ],
        declarations: [_attendence_b_edit_page__WEBPACK_IMPORTED_MODULE_1__.AttendenceBEditPage]
    })
], AttendenceBEditPageModule);



/***/ }),

/***/ 26319:
/*!*************************************************************!*\
  !*** ./src/app/attendence-b-edit/attendence-b-edit.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceBEditPage": () => (/* binding */ AttendenceBEditPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_attendence_b_edit_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./attendence-b-edit.page.html */ 20595);
/* harmony import */ var _attendence_b_edit_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence-b-edit.page.scss */ 67145);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser */ 93220);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ 73181);
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ 71074);
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/camera/ngx */ 45103);
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ 41765);
/* harmony import */ var _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/base64/ngx */ 43170);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash */ 46243);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_9__);




//import { Http, Headers, RequestOptions } from '@angular/http';


















let AttendenceBEditPage = class AttendenceBEditPage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, route, datePipe, nativeGeocoder, geolocation, camera, photoViewer, base64, sanitizer) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.route = route;
        this.datePipe = datePipe;
        this.nativeGeocoder = nativeGeocoder;
        this.geolocation = geolocation;
        this.camera = camera;
        this.photoViewer = photoViewer;
        this.base64 = base64;
        this.sanitizer = sanitizer;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.category = '';
        this.category_text = '';
        this.start_time = '';
        this.start_timenw = '';
        this.end_time = new Date().toISOString();
        this.work_description = '';
        this.clientID = '';
        this.clientCode = '';
        this.newMin = '';
        this.address = '';
        this.address2 = '';
        this.current_address = '';
        this.depositImage = "";
        this.depositImagenw = "";
        this.stindex = '';
        this.attendenceData = '';
        this.projecy_list = '';
        this.category_list = '';
        this.project_text = '';
        this.projectid = '';
        this.project_full = '';
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
        //this.clientID = this.route.snapshot.paramMap.get('clientName');
        // console.log(this.clientID);
        this.isToggled = false;
        this.stindex = this.route.snapshot.paramMap.get('index');
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        //this.storage.set("mintime",'09:30');
        //  this.storage.clear();s
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                //this.getprojectList();
                //this.getcategoryList();
                this.reloadDepositData();
            }
            else {
                this.navCtrl.navigateForward('login');
            }
        });
        this.getLocation();
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            var data = {
                "userid": this.userId,
                "id": this.stindex,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-attendence-getbyid', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.category_list = res.category_list;
                    this.projecy_list = res.project_list;
                    this.project = res.response_data[0].ua_projectid;
                    this.category = res.response_data[0].ua_category;
                    //this.subcategory=res.response_data[0].uwe_subcategory;
                    // this.expense_amount=res.response_data[0].uwe_amount;
                    this.start_time = res.response_data[0].ua_checkintime;
                    this.work_description = res.response_data[0].ua_description;
                    this.depositImage = _environments_environment__WEBPACK_IMPORTED_MODULE_3__.image_path + res.response_data[0].ua_image;
                    this.address = res.response_data[0].ua_locationin;
                }
                else {
                    this.category_list = res.category_list;
                    this.projecy_list = res.project_list;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    importFile(event, index) {
        console.log(event);
        if (event.target.files && event.target.files.length > 0) {
            let files = event.target.files || event.dataTransfer.files;
            if (!files.length)
                return;
            var fileName = files[0].name.toUpperCase();
            // this.document[index] = files[0];
            // if (fileName.endsWith(".JPG") || fileName.endsWith(".JPEG") || fileName.endsWith(".PNG")) {
            //   //console.log(files[0]);
            //   this.document[index] = files[0];
            // } else {
            //  this.document[index] = null;
            // }
        }
    }
    submit_mode() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Sending...'
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            if (!this.project) {
                this.alertController.create({
                    message: 'Please select project',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            else if (!this.category) {
                this.alertController.create({
                    message: 'Please select category',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            // else if(!this.work_description){
            //   this.alertController.create({
            //     message:'Please enter description',
            //      buttons: ['OK']
            //    }).then(resalert => {
            //      resalert.present();
            //    });
            // }
            else {
                var splitted = this.getDropDownText2(this.project, this.projecy_list);
                //console.log(splitted)
                let localarray = {
                    projectid: splitted[0].sub_project_id,
                    project: this.project,
                    project_full: this.project,
                    project_text: splitted[0].project_id + ' > ' + splitted[0].sub_project_id,
                    category: this.category,
                    category_text: this.category_text,
                    start_time: '',
                    end_time: this.datePipe.transform(this.end_time, 'hh:mm'),
                    start_time24: '',
                    end_time24: this.datePipe.transform(this.end_time, 'HH:mm'),
                    start_timef: this.start_time,
                    end_timef: this.end_time,
                    work_description: this.work_description,
                    depositImage2: this.depositImagenw,
                    address: this.address,
                    address2: this.address2,
                    ua_createdBy: this.userId,
                    id: this.stindex,
                };
                //console.log(this.end_time);
                yield loading.present();
                //console.log(this.end_time);
                this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-attendence-postbyid', JSON.stringify(localarray), { headers: headers })
                    .subscribe((res) => {
                    // console.log(res);
                    loading.dismiss();
                    if (res.status == true) {
                        this.storage.set("checkin", 0);
                        this.alertController.create({
                            message: 'Successfully updated',
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                        this.navCtrl.back();
                    }
                    else {
                        this.alertController.create({
                            message: 'Something went wrong',
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                        loading.dismiss();
                    }
                }, (err) => {
                    //console.log(err);
                    loading.dismiss();
                });
            }
        });
    }
    deposit_slip_image() {
        let options = {
            quality: 30,
            targetWidth: 768,
            targetHeight: 1360,
            // allowEdit: true,
            destinationType: this.camera.DestinationType.FILE_URI,
            sourceType: this.camera.PictureSourceType.CAMERA,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then(imageData => {
            this.base64.encodeFile(imageData).then((base64File) => {
                this.depositImage = base64File;
                this.depositImagenw = base64File;
                // this.form.controls.ddImage = this.ddImage;				
            }, (err) => {
                //	this.showToastWithCloseButton("Image capture failed. Please try again.");
            });
        }, error => {
            console.log('ERROR -> ' + JSON.stringify(error));
        });
    }
    imageViewer(imageToView, text = '') {
        this.photoViewer.show(imageToView, text);
    }
    getprojectList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-project-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.projecy_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getcategoryList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'attendence-category-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.category_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getDropDownText2(id, object) {
        const selObj = lodash__WEBPACK_IMPORTED_MODULE_9__.filter(object, function (o) {
            return (lodash__WEBPACK_IMPORTED_MODULE_9__.includes(id, o.ID));
        });
        return selObj;
    }
    getDropDownText(id, object) {
        const selObj = lodash__WEBPACK_IMPORTED_MODULE_9__.filter(object, function (o) {
            return (lodash__WEBPACK_IMPORTED_MODULE_9__.includes(id, o.ac_ID));
        });
        return selObj;
    }
    selectChange() {
        this.category_text = this.getDropDownText(this.category, this.category_list)[0].ac_name;
        // console.log(this.category_text);
    }
    getLocation() {
        this.geolocation.getCurrentPosition().then((resp) => {
            // resp.coords.latitude
            // resp.coords.longitude
            let options = {
                useLocale: true,
                maxResults: 5
            };
            this.nativeGeocoder.reverseGeocode(resp.coords.latitude, resp.coords.longitude, options)
                .then((result) => {
                // let data = {'pincode':result[0].postalCode, 'userId':10, 'type':'location', 'lat':this.latitude, 'lng': this.longitude}
                // console.log(result[0]);
                this.address2 = result[0].thoroughfare + ',' + result[0].postalCode + ',' + result[0].subAdministrativeArea
                    + ',' + result[0].administrativeArea + ',' + result[0].countryName;
            }).catch((error) => console.log(error));
        }).catch((error) => {
            console.log('Error getting location', error);
        });
    }
    getLocationRel() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            loading.present();
            this.geolocation.getCurrentPosition().then((resp) => {
                // resp.coords.latitude
                // resp.coords.longitude
                let options = {
                    useLocale: true,
                    maxResults: 5
                };
                this.nativeGeocoder.reverseGeocode(resp.coords.latitude, resp.coords.longitude, options)
                    .then((result) => {
                    loading.dismiss();
                    // let data = {'pincode':result[0].postalCode, 'userId':10, 'type':'location', 'lat':this.latitude, 'lng': this.longitude}
                    // console.log(result[0]);
                    this.address2 = result[0].thoroughfare + ',' + result[0].postalCode + ',' + result[0].subAdministrativeArea
                        + ',' + result[0].administrativeArea + ',' + result[0].countryName;
                }).catch((error) => //console.log(error)
                 loading.dismiss());
            }).catch((error) => {
                loading.dismiss();
                console.log('Error getting location', error);
            });
        });
    }
};
AttendenceBEditPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_15__.DatePipe },
    { type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_4__.NativeGeocoder },
    { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__.Geolocation },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__.Camera },
    { type: _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__.PhotoViewer },
    { type: _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_8__.Base64 },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.DomSanitizer }
];
AttendenceBEditPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.Component)({
        selector: 'app-attendence-b-edit',
        template: _raw_loader_attendence_b_edit_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_attendence_b_edit_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AttendenceBEditPage);



/***/ }),

/***/ 67145:
/*!***************************************************************!*\
  !*** ./src/app/attendence-b-edit/attendence-b-edit.page.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhdHRlbmRlbmNlLWItZWRpdC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ 20595:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/attendence-b-edit/attendence-b-edit.page.html ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">Attendance edit</ion-title>\n  </ion-toolbar>\n</ion-header> \n<ion-content>\n\n<ion-content>\n<form (ngSubmit)=\"register(form)\">\n    <ion-grid>\n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <!-- <div text-center>\n            <h3>Create your account!</h3>\n          </div> -->\n          <div padding>\n           <ion-item>\n    \n<ion-label position=\"stacked\">Project</ion-label>\n    <ion-select  interface=\"popover\"  placeholder={{project_text}} [(ngModel)]=\"project\" [ngModelOptions]=\"{standalone: true}\">\n      <ion-select-option *ngFor=\"let val of projecy_list; let i = index\" value=\"{{val.ID}}\">{{val.project_id}} > {{val.sub_project_id}}</ion-select-option>\n          \n      \n    </ion-select>\n  </ion-item> \n  <ion-item>\n    \n<ion-label position=\"stacked\">Attendance category</ion-label>\n    <ion-select #C (ionChange)=\"selectChange(C.value)\" interface=\"popover\" placeholder={{category_text}} [(ngModel)]=\"category\" [ngModelOptions]=\"{standalone: true}\">\n      <ion-select-option *ngFor=\"let val of category_list; let i = index\" value=\"{{val.ac_ID}}\">{{val.ac_name}}</ion-select-option>\n       \n    </ion-select>\n  </ion-item> \n    <ion-item>\n    \n<ion-label position=\"stacked\">Start time </ion-label>\n    \n       <ion-datetime displayFormat=\"H:mm\" [disabled]=\"true\" [(ngModel)]=\"start_time\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n    \n  </ion-item>\n   <ion-item>\n    \n<ion-label position=\"stacked\">End time</ion-label>\n   \n     <ion-datetime displayFormat=\"H:mm\"  [disabled]=\"true\" [(ngModel)]=\"end_time\" [ngModelOptions]=\"{standalone: true}\"></ion-datetime>\n   \n  </ion-item>\n  <ion-item>\n  <ion-label position=\"floating\">Work description</ion-label>\n  <ion-textarea placeholder=\"Enter more information here...\" [(ngModel)]=\"work_description\" [ngModelOptions]=\"{standalone: true}\"></ion-textarea>\n</ion-item>\n<!-- <ion-item>\n      <ion-label position=\"stacked\">Image</ion-label>\n      <ion-input type=\"file\" accept=\"image/*\" id=\"upload\"  (ionChange)=\"imageFilePath_change($event)\"></ion-input>\n    </ion-item> -->\n    <ion-row >\n      <ion-col size=\"10\">\n        <div *ngIf=\"isToggled == false\">\n        <ion-button color=\"primary\"  (click)=\"deposit_slip_image()\" expand=\"block\">\n           <ion-icon name=\"camera\" slot=\"icon-only\"></ion-icon>\n        </ion-button>\n        </div>\n      </ion-col>\n    <ion-col size=\"2\">\n      <div class=\"image_border\" *ngIf=\"depositImage\">\n        <img [src]=\"sanitizer.bypassSecurityTrustUrl(depositImage)\" (click)=\"imageViewer(depositImage)\">\n      </div>\n    </ion-col>\n    \n  </ion-row>\n    <ion-item>\n      <ion-label position=\"stacked\" style=\"position: relative;\">Location in</ion-label>\n      \n      <div *ngIf=\"address==''\"></div>\n      <div *ngIf=\"address\">{{address}}</div>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\" style=\"position: relative;\">Location Out</ion-label>\n      <div style=\"position: absolute;right: 15px;top: 6px;\"><span (click)=\"getLocationRel()\" style=\"font-size: 25px;\"><ion-icon name=\"refresh-circle-outline\"></ion-icon></span></div>\n     \n      <div *ngIf=\"address2\">{{address2}}</div>\n    </ion-item>\n\n<br>\n\n\n          </div>\n          <div padding>\n            <ion-button  size=\"large\" (click)=\"submit_mode()\"  expand=\"block\">Check Out</ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_attendence-b-edit_attendence-b-edit_module_ts.js.map