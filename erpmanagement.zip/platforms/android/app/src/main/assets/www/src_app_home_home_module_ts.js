(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_home_home_module_ts"],{

/***/ 65089:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 19460);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HomePageRoutingModule);



/***/ }),

/***/ 82711:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-routing.module */ 65089);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page */ 19460);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_0__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_1__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 19460:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./home.page.html */ 49764);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 2610);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ 73181);
/* harmony import */ var _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/location-accuracy/ngx */ 91358);
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ 71074);
/* harmony import */ var _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/android-permissions/ngx */ 68491);
/* harmony import */ var _ionic_native_battery_status_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/battery-status/ngx */ 65702);




//import { Http, Headers, RequestOptions } from '@angular/http';










let HomePage = class HomePage {
    constructor(
    //public http: Http,
    navCtrl, storage, loadingController, alertController, menu, nativeGeocoder, locationAccuracy, geolocation, androidPermissions, batteryStatus) {
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.nativeGeocoder = nativeGeocoder;
        this.locationAccuracy = locationAccuracy;
        this.geolocation = geolocation;
        this.androidPermissions = androidPermissions;
        this.batteryStatus = batteryStatus;
        this.locationCordinates = {
            latitude: "",
            longitude: "",
            accuracy: "",
            timestamp: ""
        };
        this.timestamp = Date.now();
    }
    ionViewWillEnter() {
        this.batteryStatus.onChange().subscribe(status => {
            //console.log('batteryStatus', status.level);
            // if(this.user_id != 0){
            //   this.authService.postData({'status':status.level, 'user_id':this.user_id, 'app_version': this.current_app_version}, 'changeBatteryStatus').then((result:any) => {});
            // }
        });
        // console.log("Outer")
        //    if (window.cordova) {
        //     cordova.plugins.diagnostic.isLocationEnabled(function(enabled) {
        //         alert("Location is " + (enabled ? "enabled" : "disabled"));
        //     }, function(error) {
        //         alert("The following error occurred: " + error);
        //     });
        // }
        this.getLocation();
        this.checkPermission();
        this.storage.get("genuserDetails").then(val => {
            if (val) {
            }
            else {
                this.navCtrl.navigateForward('login');
            }
        });
    }
    ngOnInit() {
    }
    openMenu() {
        this.menu.open();
    }
    checkPermission() {
        this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION).then(result => {
            if (result.hasPermission) {
                this.enableGPS();
                //console.log(result.hasPermission);
            }
            else {
                this.locationAccPermission();
                //console.log(222);
            }
        }, error => {
            alert(error);
        });
    }
    locationAccPermission() {
        this.locationAccuracy.canRequest().then((canRequest) => {
            if (canRequest) {
                //console.log(222);
            }
            else {
                //console.log(123);
                this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION)
                    .then(() => {
                    this.enableGPS();
                }, error => {
                    //alert(error)
                });
            }
        });
    }
    enableGPS() {
        this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(() => {
            this.currentLocPosition();
        }, error => alert('Please enable your GPS location')
        //1+JSON.stringify(error)
        );
    }
    currentLocPosition() {
        this.geolocation.getCurrentPosition().then((resp) => {
            // resp.coords.latitude
            // resp.coords.longitude
            let options = {
                useLocale: true,
                maxResults: 5
            };
            this.nativeGeocoder.reverseGeocode(resp.coords.latitude, resp.coords.longitude, options)
                .then((result) => {
                // let data = {'pincode':result[0].postalCode, 'userId':10, 'type':'location', 'lat':this.latitude, 'lng': this.longitude}
                // console.log(result[0])
                this.address = result[0].thoroughfare + ',' + result[0].postalCode + ',' + result[0].subAdministrativeArea
                    + ',' + result[0].administrativeArea + ',' + result[0].countryName;
            }).catch((error) => console.log(error));
        }).catch((error) => {
            console.log('Error getting location', error);
        });
    }
    getLocation() {
        this.geolocation.getCurrentPosition().then((resp) => {
            // resp.coords.latitude
            // resp.coords.longitude
            let options = {
                useLocale: true,
                maxResults: 5
            };
            this.nativeGeocoder.reverseGeocode(resp.coords.latitude, resp.coords.longitude, options)
                .then((result) => {
                // let data = {'pincode':result[0].postalCode, 'userId':10, 'type':'location', 'lat':this.latitude, 'lng': this.longitude}
                // console.log(result[0]);
                this.address = result[0].thoroughfare + ',' + result[0].postalCode + ',' + result[0].subAdministrativeArea
                    + ',' + result[0].administrativeArea + ',' + result[0].countryName + ' accuracy:' + resp.coords.accuracy;
                ;
            }).catch((error) => console.log(error));
        }).catch((error) => {
            console.log('Error getting location', error);
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.MenuController },
    { type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_3__.NativeGeocoder },
    { type: _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_4__.LocationAccuracy },
    { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__.Geolocation },
    { type: _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_6__.AndroidPermissions },
    { type: _ionic_native_battery_status_ngx__WEBPACK_IMPORTED_MODULE_7__.BatteryStatus }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], HomePage);



/***/ }),

/***/ 2610:
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".card_mntitle {\n  font-size: 18px;\n  font-weight: 600;\n  color: black;\n}\n\n.card_icon {\n  font-size: 35px;\n  color: #071662;\n}\n\n.icon_title {\n  font-size: 17px;\n  font-weight: 600;\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUNBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUFFRjs7QUFBQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUFHRiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYXJkX21udGl0bGUge1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGNvbG9yOiBibGFjaztcclxufVxyXG4uY2FyZF9pY29uIHtcclxuICBmb250LXNpemU6IDM1cHg7XHJcbiAgY29sb3I6ICMwNzE2NjI7XHJcbn1cclxuLmljb25fdGl0bGUge1xyXG4gIGZvbnQtc2l6ZTogMTdweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGNvbG9yOiBibGFjaztcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 49764:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar no-border-bottom class=\"toolbar-background\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-menu-button class=\"button-native\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title  class=\"toolbar-title\">Home</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n \n  <!-- <div *ngIf=\"address\">\n  <ion-row>\n    <ion-col>Location </ion-col>\n    <ion-col>{{address}}</ion-col>\n  </ion-row>\n</div> -->\n  \n\n    <ion-grid>\n      \n\n\n      <ion-card>\n        <ion-card-header>\n          <ion-card-subtitle class=\"card_mntitle\">Attendance</ion-card-subtitle>\n          <!-- <ion-card-title>Attendance</ion-card-title> -->\n        </ion-card-header>\n      \n        <ion-card-content>\n          <ion-row>\n        \n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/attendence-b\">\n              <ion-icon name=\"add-circle-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">Add</ion-card-title>\n            </ion-col>\n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/user-attendense-list\">\n              <ion-icon name=\"eye-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">View</ion-card-title>\n            </ion-col>\n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/attendence-report\">\n              <ion-icon name=\"book-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">Report</ion-card-title>\n            </ion-col>\n          </ion-row>\n        </ion-card-content>\n      </ion-card>\n      \n <ion-card>\n        <ion-card-header>\n          <ion-card-subtitle class=\"card_mntitle\">Expense</ion-card-subtitle>\n          <!-- <ion-card-title>Attendance</ion-card-title> -->\n        </ion-card-header>\n      \n        <ion-card-content>\n          <ion-row>\n        \n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/attendence-expense-add\">\n              <ion-icon name=\"add-circle-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">Add</ion-card-title>\n            </ion-col>\n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/workexpense-list\">\n              <ion-icon name=\"eye-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">View</ion-card-title>\n            </ion-col>\n          </ion-row>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card>\n        <ion-card-header>\n          <ion-card-subtitle class=\"card_mntitle\">My Leave</ion-card-subtitle>\n          <!-- <ion-card-title>Attendance</ion-card-title> -->\n        </ion-card-header>\n      \n        <ion-card-content>\n          <ion-row>\n            \n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/generale-leave\">\n              <ion-icon name=\"radio-button-off-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">General</ion-card-title>\n            </ion-col>\n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/medical-leave\">\n              <ion-icon name=\"radio-button-off-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">Medical</ion-card-title>\n            </ion-col>\n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/compact-leave\">\n              <ion-icon name=\"radio-button-off-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">Comp</ion-card-title>\n            </ion-col>\n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/leave-page\">\n              <ion-icon name=\"eye-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">View</ion-card-title>\n            </ion-col>\n          </ion-row>\n        </ion-card-content>\n      </ion-card>\n      <ion-card>\n        <ion-card-header>\n          <ion-card-subtitle class=\"card_mntitle\">Transaction</ion-card-subtitle>\n          <!-- <ion-card-title>Attendance</ion-card-title> -->\n        </ion-card-header>\n      \n        <ion-card-content>\n          <ion-row>\n        \n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/wallet-page\">\n              <ion-icon name=\"wallet-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">Wallet</ion-card-title>\n            </ion-col>\n            <ion-col style=\"text-align: center;\" size=\"3\" routerLink=\"/sallery-list\">\n              <ion-icon name=\"cash-outline\" class=\"card_icon\"></ion-icon>\n              <ion-card-title class=\"icon_title\">Salery</ion-card-title>\n            </ion-col>\n          </ion-row>\n        </ion-card-content>\n      </ion-card>\n\n    </ion-grid>\n  \n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map