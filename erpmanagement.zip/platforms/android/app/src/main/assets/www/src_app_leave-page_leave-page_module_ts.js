(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_leave-page_leave-page_module_ts"],{

/***/ 19530:
/*!*********************************************************!*\
  !*** ./src/app/leave-page/leave-page-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LeavePagePageRoutingModule": () => (/* binding */ LeavePagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _leave_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./leave-page.page */ 17775);




const routes = [
    {
        path: '',
        component: _leave_page_page__WEBPACK_IMPORTED_MODULE_0__.LeavePagePage
    }
];
let LeavePagePageRoutingModule = class LeavePagePageRoutingModule {
};
LeavePagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LeavePagePageRoutingModule);



/***/ }),

/***/ 60692:
/*!*************************************************!*\
  !*** ./src/app/leave-page/leave-page.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LeavePagePageModule": () => (/* binding */ LeavePagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _leave_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./leave-page-routing.module */ 19530);
/* harmony import */ var _leave_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./leave-page.page */ 17775);







let LeavePagePageModule = class LeavePagePageModule {
};
LeavePagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _leave_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.LeavePagePageRoutingModule
        ],
        declarations: [_leave_page_page__WEBPACK_IMPORTED_MODULE_1__.LeavePagePage]
    })
], LeavePagePageModule);



/***/ }),

/***/ 17775:
/*!***********************************************!*\
  !*** ./src/app/leave-page/leave-page.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LeavePagePage": () => (/* binding */ LeavePagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_leave_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./leave-page.page.html */ 27781);
/* harmony import */ var _leave_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./leave-page.page.scss */ 68436);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 16274);




//import { Http, Headers, RequestOptions } from '@angular/http';









let LeavePagePage = class LeavePagePage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_amount = 0;
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.search_date = '';
        this.search_category = '';
        this.search_status = '';
        this.total_leave = '';
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
            }
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ionViewWillEnter() {
        this.reloadDepositData();
    }
    ionViewDidEnter() {
        //  this.storage.clear();
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            yield loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_date": this.search_date,
                "search_status": this.search_status,
                "leave_type": '',
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-leave-application-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_leave = res.total_leave;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    selectDate(dt) {
        this.search_date = this.datePipe.transform(dt, 'Y-MM-dd');
        // console.log(jj);
        this.reloadDepositData();
    }
    selectStatus(id) {
        this.search_status = id;
        //console.log(id);
        this.reloadDepositData();
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/return-request', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-single-edit', {
                index: i,
            }]);
    }
    remove_attendence(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            this.storage.forEach((value, key, index) => {
                                if (key == 'attendenceData') {
                                    value.forEach((val, key) => {
                                        if (key == id) {
                                            this.depositData.splice(key, 1);
                                            this.storage.remove(key).then((r) => {
                                                if (id == 0) {
                                                    this.storage.set("mintime", '');
                                                }
                                                else {
                                                    value.forEach((val2, key2) => {
                                                        if (key2 == (id - 1)) {
                                                            //console.log(val2.mintime);
                                                            this.storage.set("mintime", val2.mintime);
                                                        }
                                                    });
                                                }
                                                this.storage.set('attendenceData', this.depositData).then((r) => {
                                                    ;
                                                    this.reloadDepositData();
                                                    // this.storage.set("mintime",'06:30');
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
LeavePagePage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__.DatePipe }
];
LeavePagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-leave-page',
        template: _raw_loader_leave_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_leave_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LeavePagePage);



/***/ }),

/***/ 68436:
/*!*************************************************!*\
  !*** ./src/app/leave-page/leave-page.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".list-header-md {\n  border-top: 0;\n}\n\n.segment-md .segment-button.activated,\n.segment-md .segment-button.segment-activated {\n  color: white;\n  border-color: #ffffff;\n  opacity: 1;\n  font-size: 14px;\n}\n\n.segment-md .segment-button {\n  color: white;\n  font-size: 14px;\n}\n\nion-segment-button.inner-segment.segment-button.segment-activated {\n  color: black;\n  border-color: black;\n}\n\nion-segment-button.inner-segment.segment-button {\n  color: lightgrey;\n  font-size: 14px;\n}\n\n.cs-header {\n  margin-bottom: 0;\n  background: white;\n  margin: 7px 0;\n  border-radius: 4px;\n}\n\n.checked {\n  color: green;\n}\n\n.cross {\n  color: red;\n}\n\n.backgrey {\n  background: rgba(0, 0, 0, 0.1);\n}\n\n.searchbar-md {\n  padding: 10px 0;\n}\n\n.cscard {\n  padding: 0;\n}\n\n.cscard .label-md {\n  margin: 0;\n}\n\n.cscard .item-md {\n  padding-left: 8px;\n}\n\n.cslist {\n  background: white;\n}\n\n.cslist .card-md {\n  margin: 0;\n  width: 100%;\n}\n\n.cslist .sc-ion-card-md-h {\n  margin-left: 0;\n  margin-right: 0;\n}\n\n.icon-big {\n  font-size: 1.6em;\n}\n\n.icon-right {\n  margin: 0;\n  padding: 0px;\n  line-height: 0;\n  float: right;\n}\n\n.back ion-item-sliding {\n  /*border: 1px solid #deeaff;*/\n  border-radius: 4px;\n  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 3px 1px -2px rgba(0, 0, 0, 0.12), 0 1px 5px 0 rgba(0, 0, 0, 0.2);\n}\n\n.list-md {\n  margin: 0px 0 12px;\n}\n\n.list-md ion-item-options {\n  border-bottom: none;\n}\n\n.forward-icon {\n  font-size: 2em;\n}\n\n.bordered-row {\n  border: 1px solid gainsboro;\n  padding: 7px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-slip {\n  border: 1px solid gainsboro;\n  padding: 1px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-blue-slip {\n  border: 1px solid #0091ea;\n  padding: 1px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-slip .label-md,\n.bordered-row-blue-slip .label-md {\n  margin: 3px 0px 3px 0;\n}\n\n.bordered-row-blue-slip .label-md,\n.bordered-row-blue-slip .text-input[disabled] {\n  color: #0091ea;\n}\n\n.bordered-row-blue-slip .item-button {\n  padding: 5px 8px;\n  height: auto;\n  font-size: 2.2rem;\n  box-shadow: none;\n}\n\n.back {\n  background: #f8f8f8;\n}\n\n.image_border {\n  border: 1px dashed lightgrey;\n  padding: 3px 3px 0px 3px;\n  border-radius: 6px;\n}\n\n.image_border img {\n  border-radius: 4px;\n  height: 35px;\n  width: 32px;\n}\n\n.list-title {\n  font-weight: 500;\n  color: #00364e;\n  font-size: 14px;\n}\n\n.list-title span {\n  color: #00b0ff;\n}\n\n.list-arrow {\n  color: #00b0ff;\n}\n\n.item-p {\n  color: #9e9e9e;\n}\n\n.pending-border {\n  border-left: 3px solid #ff0027;\n  margin-bottom: 12px;\n}\n\n.processing-border {\n  border-left: 3px solid #ffdc00;\n  margin-bottom: 12px;\n}\n\n.completed-border {\n  border-left: 3px solid #25e6c1;\n  margin-bottom: 12px;\n}\n\n.submitted-border {\n  border-left: 3px solid #00ab52;\n  margin-bottom: 12px;\n}\n\n.approved-border {\n  border-left: 3px solid #663399;\n  margin-bottom: 12px;\n}\n\n.back-grey {\n  background: #e8e8e8;\n  z-index: 9999999;\n}\n\nion-card-header {\n  font-weight: bold;\n}\n\n.nonet {\n  background: red;\n  color: white;\n  text-align: center;\n  width: 100%;\n  font-size: 14px;\n  z-index: 9999;\n}\n\n.smspan {\n  font-size: 12px;\n}\n\n.nomargin {\n  margin-top: 2px;\n  margin-bottom: 2px;\n}\n\n.shortmargin {\n  margin-right: 12px !important;\n}\n\n.margin {\n  margin-top: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxlYXZlLXBhZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtBQUNGOztBQUVBOztFQUVFLFlBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxnQkFBQTtFQUNBLGVBQUE7QUFFRjs7QUFBQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUFHRjs7QUFEQTtFQUNFLFlBQUE7QUFJRjs7QUFGQTtFQUNFLFVBQUE7QUFLRjs7QUFIQTtFQUNFLDhCQUFBO0FBTUY7O0FBSkE7RUFDRSxlQUFBO0FBT0Y7O0FBTEE7RUFDRSxVQUFBO0FBUUY7O0FBTkE7RUFDRSxTQUFBO0FBU0Y7O0FBUEE7RUFDRSxpQkFBQTtBQVVGOztBQVJBO0VBQ0UsaUJBQUE7QUFXRjs7QUFUQTtFQUNFLFNBQUE7RUFDQSxXQUFBO0FBWUY7O0FBVkE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQWFGOztBQVhBO0VBQ0UsZ0JBQUE7QUFjRjs7QUFaQTtFQUNFLFNBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFlRjs7QUFiQTtFQUNFLDZCQUFBO0VBQ0Esa0JBQUE7RUFFQSwrR0FBQTtBQWVGOztBQVpBO0VBQ0Usa0JBQUE7QUFlRjs7QUFiQTtFQUNFLG1CQUFBO0FBZ0JGOztBQWRBO0VBQ0UsY0FBQTtBQWlCRjs7QUFmQTtFQUNFLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFrQkY7O0FBaEJBO0VBQ0UsMkJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQW1CRjs7QUFqQkE7RUFDRSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBb0JGOztBQWxCQTs7RUFFRSxxQkFBQTtBQXFCRjs7QUFuQkE7O0VBRUUsY0FBQTtBQXNCRjs7QUFwQkE7RUFDRSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBdUJGOztBQXJCQTtFQUNFLG1CQUFBO0FBd0JGOztBQXRCQTtFQUNFLDRCQUFBO0VBQ0Esd0JBQUE7RUFDQSxrQkFBQTtBQXlCRjs7QUF2QkE7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBMEJGOztBQXhCQTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUEyQkY7O0FBekJBO0VBQ0UsY0FBQTtBQTRCRjs7QUExQkE7RUFDRSxjQUFBO0FBNkJGOztBQTNCQTtFQUNFLGNBQUE7QUE4QkY7O0FBNUJBO0VBQ0UsOEJBQUE7RUFDQSxtQkFBQTtBQStCRjs7QUE3QkE7RUFDRSw4QkFBQTtFQUNBLG1CQUFBO0FBZ0NGOztBQTlCQTtFQUNFLDhCQUFBO0VBQ0EsbUJBQUE7QUFpQ0Y7O0FBL0JBO0VBQ0UsOEJBQUE7RUFDQSxtQkFBQTtBQWtDRjs7QUFoQ0E7RUFDRSw4QkFBQTtFQUNBLG1CQUFBO0FBbUNGOztBQWpDQTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7QUFvQ0Y7O0FBakNBO0VBQ0UsaUJBQUE7QUFvQ0Y7O0FBbENBO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtBQXFDRjs7QUFuQ0E7RUFDRSxlQUFBO0FBc0NGOztBQXBDQTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQXVDRjs7QUFyQ0E7RUFDRSw2QkFBQTtBQXdDRjs7QUF0Q0E7RUFDRSxlQUFBO0FBeUNGIiwiZmlsZSI6ImxlYXZlLXBhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxpc3QtaGVhZGVyLW1kIHtcclxuICBib3JkZXItdG9wOiAwO1xyXG59XHJcblxyXG4uc2VnbWVudC1tZCAuc2VnbWVudC1idXR0b24uYWN0aXZhdGVkLFxyXG4uc2VnbWVudC1tZCAuc2VnbWVudC1idXR0b24uc2VnbWVudC1hY3RpdmF0ZWQge1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXItY29sb3I6ICNmZmZmZmY7XHJcbiAgb3BhY2l0eTogMTtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuXHJcbi5zZWdtZW50LW1kIC5zZWdtZW50LWJ1dHRvbiB7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuaW9uLXNlZ21lbnQtYnV0dG9uLmlubmVyLXNlZ21lbnQuc2VnbWVudC1idXR0b24uc2VnbWVudC1hY3RpdmF0ZWQge1xyXG4gIGNvbG9yOiBibGFjaztcclxuICBib3JkZXItY29sb3I6IGJsYWNrO1xyXG59XHJcbmlvbi1zZWdtZW50LWJ1dHRvbi5pbm5lci1zZWdtZW50LnNlZ21lbnQtYnV0dG9uIHtcclxuICBjb2xvcjogbGlnaHRncmV5O1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG4uY3MtaGVhZGVyIHtcclxuICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gIG1hcmdpbjogN3B4IDA7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG59XHJcbi5jaGVja2VkIHtcclxuICBjb2xvcjogZ3JlZW47XHJcbn1cclxuLmNyb3NzIHtcclxuICBjb2xvcjogcmVkO1xyXG59XHJcbi5iYWNrZ3JleSB7XHJcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG59XHJcbi5zZWFyY2hiYXItbWQge1xyXG4gIHBhZGRpbmc6IDEwcHggMDtcclxufVxyXG4uY3NjYXJkIHtcclxuICBwYWRkaW5nOiAwO1xyXG59XHJcbi5jc2NhcmQgLmxhYmVsLW1kIHtcclxuICBtYXJnaW46IDA7XHJcbn1cclxuLmNzY2FyZCAuaXRlbS1tZCB7XHJcbiAgcGFkZGluZy1sZWZ0OiA4cHg7XHJcbn1cclxuLmNzbGlzdCB7XHJcbiAgYmFja2dyb3VuZDogd2hpdGU7XHJcbn1cclxuLmNzbGlzdCAuY2FyZC1tZCB7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcbi5jc2xpc3QgLnNjLWlvbi1jYXJkLW1kLWgge1xyXG4gIG1hcmdpbi1sZWZ0OiAwO1xyXG4gIG1hcmdpbi1yaWdodDogMDtcclxufVxyXG4uaWNvbi1iaWcge1xyXG4gIGZvbnQtc2l6ZTogMS42ZW07XHJcbn1cclxuLmljb24tcmlnaHQge1xyXG4gIG1hcmdpbjogMDtcclxuICBwYWRkaW5nOiAwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDA7XHJcbiAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcbi5iYWNrIGlvbi1pdGVtLXNsaWRpbmcge1xyXG4gIC8qYm9yZGVyOiAxcHggc29saWQgI2RlZWFmZjsqL1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAvLyBib3gtc2hhZG93OiAxcHggMXB4IDVweCBsaWdodGdyZXk7XHJcbiAgYm94LXNoYWRvdzogMCAycHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjE0KSxcclxuICAgIDAgM3B4IDFweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC4xMiksIDAgMXB4IDVweCAwIHJnYmEoMCwgMCwgMCwgMC4yKTtcclxufVxyXG4ubGlzdC1tZCB7XHJcbiAgbWFyZ2luOiAwcHggMCAxMnB4O1xyXG59XHJcbi5saXN0LW1kIGlvbi1pdGVtLW9wdGlvbnMge1xyXG4gIGJvcmRlci1ib3R0b206IG5vbmU7XHJcbn1cclxuLmZvcndhcmQtaWNvbiB7XHJcbiAgZm9udC1zaXplOiAyZW07XHJcbn1cclxuLmJvcmRlcmVkLXJvdyB7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgZ2FpbnNib3JvO1xyXG4gIHBhZGRpbmc6IDdweCAwO1xyXG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG59XHJcbi5ib3JkZXJlZC1yb3ctc2xpcCB7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgZ2FpbnNib3JvO1xyXG4gIHBhZGRpbmc6IDFweCAwO1xyXG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG59XHJcbi5ib3JkZXJlZC1yb3ctYmx1ZS1zbGlwIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjMDA5MWVhO1xyXG4gIHBhZGRpbmc6IDFweCAwO1xyXG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG59XHJcbi5ib3JkZXJlZC1yb3ctc2xpcCAubGFiZWwtbWQsXHJcbi5ib3JkZXJlZC1yb3ctYmx1ZS1zbGlwIC5sYWJlbC1tZCB7XHJcbiAgbWFyZ2luOiAzcHggMHB4IDNweCAwO1xyXG59XHJcbi5ib3JkZXJlZC1yb3ctYmx1ZS1zbGlwIC5sYWJlbC1tZCxcclxuLmJvcmRlcmVkLXJvdy1ibHVlLXNsaXAgLnRleHQtaW5wdXRbZGlzYWJsZWRdIHtcclxuICBjb2xvcjogIzAwOTFlYTtcclxufVxyXG4uYm9yZGVyZWQtcm93LWJsdWUtc2xpcCAuaXRlbS1idXR0b24ge1xyXG4gIHBhZGRpbmc6IDVweCA4cHg7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gIGZvbnQtc2l6ZTogMi4ycmVtO1xyXG4gIGJveC1zaGFkb3c6IG5vbmU7XHJcbn1cclxuLmJhY2sge1xyXG4gIGJhY2tncm91bmQ6ICNmOGY4Zjg7XHJcbn1cclxuLmltYWdlX2JvcmRlciB7XHJcbiAgYm9yZGVyOiAxcHggZGFzaGVkIGxpZ2h0Z3JleTtcclxuICBwYWRkaW5nOiAzcHggM3B4IDBweCAzcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG59XHJcbi5pbWFnZV9ib3JkZXIgaW1nIHtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgaGVpZ2h0OiAzNXB4O1xyXG4gIHdpZHRoOiAzMnB4O1xyXG59XHJcbi5saXN0LXRpdGxlIHtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGNvbG9yOiAjMDAzNjRlO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG4ubGlzdC10aXRsZSBzcGFuIHtcclxuICBjb2xvcjogIzAwYjBmZjtcclxufVxyXG4ubGlzdC1hcnJvdyB7XHJcbiAgY29sb3I6ICMwMGIwZmY7XHJcbn1cclxuLml0ZW0tcCB7XHJcbiAgY29sb3I6ICM5ZTllOWU7XHJcbn1cclxuLnBlbmRpbmctYm9yZGVyIHtcclxuICBib3JkZXItbGVmdDogM3B4IHNvbGlkICNmZjAwMjc7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcclxufVxyXG4ucHJvY2Vzc2luZy1ib3JkZXIge1xyXG4gIGJvcmRlci1sZWZ0OiAzcHggc29saWQgI2ZmZGMwMDtcclxuICBtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG59XHJcbi5jb21wbGV0ZWQtYm9yZGVyIHtcclxuICBib3JkZXItbGVmdDogM3B4IHNvbGlkICMyNWU2YzE7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcclxufVxyXG4uc3VibWl0dGVkLWJvcmRlciB7XHJcbiAgYm9yZGVyLWxlZnQ6IDNweCBzb2xpZCAjMDBhYjUyO1xyXG4gIG1hcmdpbi1ib3R0b206IDEycHg7XHJcbn1cclxuLmFwcHJvdmVkLWJvcmRlciB7XHJcbiAgYm9yZGVyLWxlZnQ6IDNweCBzb2xpZCAjNjYzMzk5O1xyXG4gIG1hcmdpbi1ib3R0b206IDEycHg7XHJcbn1cclxuLmJhY2stZ3JleSB7XHJcbiAgYmFja2dyb3VuZDogI2U4ZThlODtcclxuICB6LWluZGV4OiA5OTk5OTk5O1xyXG59XHJcblxyXG5pb24tY2FyZC1oZWFkZXIge1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcbi5ub25ldCB7XHJcbiAgYmFja2dyb3VuZDogcmVkO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIHotaW5kZXg6IDk5OTk7XHJcbn1cclxuLnNtc3BhbiB7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcbi5ub21hcmdpbiB7XHJcbiAgbWFyZ2luLXRvcDogMnB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDJweDtcclxufVxyXG4uc2hvcnRtYXJnaW4ge1xyXG4gIG1hcmdpbi1yaWdodDogMTJweCAhaW1wb3J0YW50O1xyXG59XHJcbi5tYXJnaW4ge1xyXG4gIG1hcmdpbi10b3A6IDhweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 27781:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/leave-page/leave-page.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">My Leave</ion-title>\n  </ion-toolbar>\n</ion-header> \n<ion-content>\n\n<ion-content>\n<form  (ngSubmit)=\"register(form)\">\n    <ion-grid>\n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <!-- <div text-center>\n            <h3>Create your account!</h3>\n          </div> -->\n          <ion-grid>\n            <ion-row>\n              <ion-col size=\"8\">\n                <ion-item-divider  color=\"light\">Total Generale Leave : <div> {{total_leave.gen}}</div></ion-item-divider>\n                </ion-col>\n                \n\n                <ion-col size=\"8\">\n                  <ion-item-divider  color=\"light\">Total Medical Leave : <div> {{total_leave.med}}</div></ion-item-divider>\n                  </ion-col>\n                </ion-row>\n                  <ion-row>\n\n                  <ion-col size=\"6\">\n                      \n                    <ion-button size=\"small\" color=\"primary\" routerLink='/generale-leave'>Gen Leave Apply</ion-button>\n                  </ion-col>\n                    <ion-col size=\"6\">\n                      \n                      <ion-button size=\"small\" color=\"primary\" routerLink='/generale-leave'>Med Leave Apply</ion-button>\n                    </ion-col>\n                </ion-row>\n\n                <ion-row color=\"primary\" justify-content-center>\n                  <ion-col align-self-center size=\"7\" >\n                  \n                   \n                    <ion-item>\n          \n                      <ion-label position=\"stacked\">Status</ion-label>\n                          \n                      <ion-select #S (ionChange)=\"selectStatus(S.value)\" interface=\"popover\" placeholder=\"Select status\" [(ngModel)]=\"search_status\" [ngModelOptions]=\"{standalone: true}\">\n                        <ion-select-option value=\"active\">Success</ion-select-option>\n                        <ion-select-option value=\"inactive\">Pending</ion-select-option>\n                        <ion-select-option value=\"reject\">Reject</ion-select-option>\n                      </ion-select>\n                        </ion-item>\n             </ion-col>\n             <ion-col align-self-center size=\"5\" >\n              <ion-item>\n              \n          <ion-label position=\"stacked\">Date</ion-label>\n              \n                 <ion-datetime #D (ionChange)=\"selectDate(D.value)\" placeholder=\"Date (D/M/Y)\" displayFormat=\"DD/MMM/YYYY\"  [(ngModel)]=\"search_date\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n              \n            </ion-item>\n    \n           \n            </ion-col>\n            </ion-row>\n           \n            <ion-row class=\"margin\">\n              <ion-col size=\"12\">\n                <div *ngFor=\"let inneritem of depositData; let i = index\">\n                  <ion-item-sliding #slidingItem1 class=\"submitted-border\">\n                    <ion-item lines=\"none\" color=\"grey\">\n                      <div slot=\"start\" class=\"shortmargin\">\n                        <h4>{{(i+1)}}</h4>\n                      </div>\n                      <ion-label class=\"nomargin\">  \n                          <ion-row>\n                            <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Leave day: </span><br>\n                              <span *ngIf=\"inneritem.la_leaveday_type=='both'\" style=\"color: black;\">Both</span>\n                              <span *ngIf=\"inneritem.la_leaveday_type=='1sthalf'\" style=\"color: black;\">1st Half</span>\n                              <span *ngIf=\"inneritem.la_leaveday_type=='2ndhalf'\" style=\"color: black;\">2nd Half</span>\n                              </h2>\n                            </ion-col>\n                            <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Status: </span><br>\n                                <ion-badge color=\"success\"  *ngIf=\"inneritem.la_status=='active'\">Success</ion-badge>\n                                <ion-badge color=\"warning\"  *ngIf=\"inneritem.la_status=='inactive'\">Pending</ion-badge>\n                              </h2>\n                            </ion-col>\n                            <ion-col size=\"4\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Date: </span><br>\n                                {{inneritem.created_at | date:'MMM dd, yyyy'}}\n                              </h2>\n                            </ion-col>\n                            \n                          </ion-row>\n                          <ion-row>\n                            <ion-col size=\"12\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Reason: </span>\n                                {{inneritem.la_description}}\n                              </h2>\n                              </ion-col>\n                              </ion-row>\n                        </ion-label>\n                       \n                    </ion-item>\n                  </ion-item-sliding>\n                </div>\n                <div *ngIf=\"!depositData.length\">\n\n                  <ion-row>\n                    <ion-col size=\"12\">\n   <h2 class=\"list-title\" style=\"font-size: 22px;color: #af1313;text-align: center; font-weight: 600;\"> No record found \n                       \n                      </h2>\n                      </ion-col>\n                      </ion-row>\n                </div>\n              </ion-col>\n              <!-- <ion-col size=\"12\" *ngIf=\"total_work_hrs<9\">\n                <div class=\"ion-text-center\">\n                <ion-button color=\"primary\" fill=\"outline\" (click)=\"addAttendence()\">\n                  <ion-icon slot=\"start\" name=\"add-circle-outline\"></ion-icon>\n                  Add Attendence\n                </ion-button>\n              </div>\n              </ion-col> -->\n            </ion-row>\n          </ion-grid>\n          <!-- <div padding *ngIf=\"total_work_hrs==9 && total_work_min==0\">\n            <ion-button  size=\"large\" (click)=\"openMenu()\"  expand=\"block\">Submit</ion-button>\n          </div>\n          <div padding *ngIf=\"total_work_hrs!=9\">\n            <ion-button  size=\"large\"  [disabled]=\"true\"  expand=\"block\">Submit</ion-button>\n          </div> -->\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    \n  </form>\n  \n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_leave-page_leave-page_module_ts.js.map