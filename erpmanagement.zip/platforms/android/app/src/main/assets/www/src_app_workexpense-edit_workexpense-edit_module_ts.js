(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_workexpense-edit_workexpense-edit_module_ts"],{

/***/ 2365:
/*!*********************************************************************!*\
  !*** ./src/app/workexpense-edit/workexpense-edit-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WorkexpenseEditPageRoutingModule": () => (/* binding */ WorkexpenseEditPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _workexpense_edit_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./workexpense-edit.page */ 14586);




const routes = [
    {
        path: '',
        component: _workexpense_edit_page__WEBPACK_IMPORTED_MODULE_0__.WorkexpenseEditPage
    }
];
let WorkexpenseEditPageRoutingModule = class WorkexpenseEditPageRoutingModule {
};
WorkexpenseEditPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], WorkexpenseEditPageRoutingModule);



/***/ }),

/***/ 24329:
/*!*************************************************************!*\
  !*** ./src/app/workexpense-edit/workexpense-edit.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WorkexpenseEditPageModule": () => (/* binding */ WorkexpenseEditPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _workexpense_edit_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./workexpense-edit-routing.module */ 2365);
/* harmony import */ var _workexpense_edit_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./workexpense-edit.page */ 14586);







let WorkexpenseEditPageModule = class WorkexpenseEditPageModule {
};
WorkexpenseEditPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _workexpense_edit_routing_module__WEBPACK_IMPORTED_MODULE_0__.WorkexpenseEditPageRoutingModule
        ],
        declarations: [_workexpense_edit_page__WEBPACK_IMPORTED_MODULE_1__.WorkexpenseEditPage]
    })
], WorkexpenseEditPageModule);



/***/ }),

/***/ 14586:
/*!***********************************************************!*\
  !*** ./src/app/workexpense-edit/workexpense-edit.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WorkexpenseEditPage": () => (/* binding */ WorkexpenseEditPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_workexpense_edit_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./workexpense-edit.page.html */ 87263);
/* harmony import */ var _workexpense_edit_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./workexpense-edit.page.scss */ 85124);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser */ 93220);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ 73181);
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ 71074);
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/camera/ngx */ 45103);
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ 41765);
/* harmony import */ var _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/base64/ngx */ 43170);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash */ 46243);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_9__);




//import { Http, Headers, RequestOptions } from '@angular/http';


















let WorkexpenseEditPage = class WorkexpenseEditPage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, route, datePipe, nativeGeocoder, geolocation, camera, photoViewer, base64, sanitizer) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.route = route;
        this.datePipe = datePipe;
        this.nativeGeocoder = nativeGeocoder;
        this.geolocation = geolocation;
        this.camera = camera;
        this.photoViewer = photoViewer;
        this.base64 = base64;
        this.sanitizer = sanitizer;
        this.image_path = _environments_environment__WEBPACK_IMPORTED_MODULE_3__.image_path;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.category = '';
        this.start_time = '';
        this.start_timenw = '';
        this.end_time = '';
        this.work_description = '';
        this.clientID = '';
        this.clientCode = '';
        this.newMin = '';
        this.address = '';
        this.current_address = '';
        this.expense_amount = '';
        this.stindex = '';
        this.depositImage = "";
        this.depositImage2 = "";
        this.projecy_list = "";
        this.category_list = '';
        this.category_text = '';
        this.subcategory_list = '';
        this.subcategory_text = '';
        this.subcategory = '';
        this.project_text = '';
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
        this.stindex = this.route.snapshot.paramMap.get('id');
        this.isToggled = false;
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        //this.storage.set("mintime",'09:30');
        //  this.storage.clear();s
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                //this.getprojectList();
                //this.getcategoryList();
                this.reloadDepositData();
            }
            else {
                this.navCtrl.navigateForward('login');
            }
        });
        this.getLocation();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    importFile(event, index) {
        //console.log(event);
        if (event.target.files && event.target.files.length > 0) {
            let files = event.target.files || event.dataTransfer.files;
            if (!files.length)
                return;
            var fileName = files[0].name.toUpperCase();
            // this.document[index] = files[0];
            // if (fileName.endsWith(".JPG") || fileName.endsWith(".JPEG") || fileName.endsWith(".PNG")) {
            //   //console.log(files[0]);
            //   this.document[index] = files[0];
            // } else {
            //  this.document[index] = null;
            // }
        }
    }
    submit_mode() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            if (!this.project) {
                this.alertController.create({
                    message: 'Please select project',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            else if (!this.category) {
                this.alertController.create({
                    message: 'Please select category',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            else if (!this.subcategory) {
                this.alertController.create({
                    message: 'Please select type',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            else if (!this.expense_amount) {
                this.alertController.create({
                    message: 'Please enter amount',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            else if (!this.work_description) {
                this.alertController.create({
                    message: 'Please enter description',
                    buttons: ['OK']
                }).then(resalert => {
                    resalert.present();
                });
            }
            else {
                yield loading.present();
                let localarray = {
                    "userid": this.userId,
                    "id": this.stindex,
                    "project": this.project,
                    "projectid": this.project,
                    "category": this.category,
                    "subcategory": this.subcategory,
                    "expense_amount": this.expense_amount,
                    "work_description": this.work_description,
                    "depositImage2": this.depositImage2,
                    //"address":this.address,
                };
                //console.log(this.end_time);
                this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-work-expense-postbyid', JSON.stringify(localarray), { headers: headers })
                    .subscribe((res) => {
                    // console.log(res);
                    loading.dismiss();
                    if (res.status == true) {
                        this.alertController.create({
                            message: 'Successfully updated',
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                    }
                    else {
                        this.alertController.create({
                            message: 'Something went wrong',
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                        loading.dismiss();
                    }
                }, (err) => {
                    //console.log(err);
                    loading.dismiss();
                });
            }
        });
    }
    getprojectList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-project-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.projecy_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getcategoryList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'expense-category-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.category_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getsubcategoryList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "catid": this.category,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'expense-subcategory-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.subcategory_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getDropDownText2(id, object) {
        const selObj = lodash__WEBPACK_IMPORTED_MODULE_9__.filter(object, function (o) {
            return (lodash__WEBPACK_IMPORTED_MODULE_9__.includes(id, o.ID));
        });
        return selObj;
    }
    getDropDownText(id, object) {
        const selObj = lodash__WEBPACK_IMPORTED_MODULE_9__.filter(object, function (o) {
            return (lodash__WEBPACK_IMPORTED_MODULE_9__.includes(id, o.ec_ID));
        });
        return selObj;
    }
    selectChange(id) {
        this.getsubcategoryList();
        this.category_text = this.getDropDownText(id, this.category_list)[0].ec_name;
        // console.log(this.category_text);
    }
    getDropDownTextsub(id, object) {
        const selObj = lodash__WEBPACK_IMPORTED_MODULE_9__.filter(object, function (o) {
            return (lodash__WEBPACK_IMPORTED_MODULE_9__.includes(id, o.ec_ID));
        });
        return selObj;
    }
    selectChangesub(id) {
        //this.getsubcategoryList();
        this.subcategory_text = this.getDropDownTextsub(id, this.subcategory_list)[0].ec_name;
        // console.log(this.category_text);
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            var data = {
                "userid": this.userId,
                "id": this.stindex,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-work-expense-getbyid', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.category_list = res.category_list;
                    this.projecy_list = res.project_list;
                    this.subcategory_list = res.subcategory_list;
                    this.project = res.response_data[0].uwe_project;
                    this.category = res.response_data[0].uwe_category;
                    // if(res.response_data[0].uwe_category){
                    //   this.getsubcategoryList();
                    // }
                    this.expense_amount = res.response_data[0].uwe_amount;
                    this.work_description = res.response_data[0].uwe_description;
                    this.depositImage = _environments_environment__WEBPACK_IMPORTED_MODULE_3__.image_path + res.response_data[0].uwe_image;
                    this.address = res.response_data[0].uwe_locationin;
                    this.subcategory = res.response_data[0].uwe_subcategory;
                }
                else {
                    this.category_list = res.category_list;
                    this.projecy_list = res.project_list;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    reloadDepositData2() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            //let d
            yield this.storage.forEach((value, key, index) => {
                if (key == 'attendenceExpense') {
                    value.forEach((element, index) => {
                        if (index == this.stindex) {
                            this.project = element.project;
                            this.category = element.category;
                            this.expense_amount = element.expense_amount;
                            this.work_description = element.work_description;
                            this.depositImage = element.depositImage;
                            this.address = element.address;
                            //console.log(element.mintime);
                        }
                    });
                }
            });
        });
    }
    deposit_slip_image() {
        let options = {
            quality: 20,
            targetWidth: 768,
            targetHeight: 1360,
            // allowEdit: true,
            destinationType: this.camera.DestinationType.FILE_URI,
            sourceType: this.camera.PictureSourceType.CAMERA,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then(imageData => {
            this.base64.encodeFile(imageData).then((base64File) => {
                this.depositImage = base64File;
                this.depositImage2 = base64File;
                // this.form.controls.ddImage = this.ddImage;				
            }, (err) => {
                //	this.showToastWithCloseButton("Image capture failed. Please try again.");
            });
        }, error => {
            console.log('ERROR -> ' + JSON.stringify(error));
        });
    }
    imageViewer(imageToView, text = '') {
        this.photoViewer.show(imageToView, text);
    }
    getLocation() {
        this.geolocation.getCurrentPosition().then((resp) => {
            // resp.coords.latitude
            // resp.coords.longitude
            let options = {
                useLocale: true,
                maxResults: 5
            };
            this.nativeGeocoder.reverseGeocode(resp.coords.latitude, resp.coords.longitude, options)
                .then((result) => {
                // let data = {'pincode':result[0].postalCode, 'userId':10, 'type':'location', 'lat':this.latitude, 'lng': this.longitude}
                // console.log(result[0]);
                this.address = result[0].thoroughfare + ',' + result[0].postalCode + ',' + result[0].subAdministrativeArea
                    + ',' + result[0].administrativeArea + ',' + result[0].countryName;
            }).catch((error) => console.log(error));
        }).catch((error) => {
            console.log('Error getting location', error);
        });
    }
};
WorkexpenseEditPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_15__.DatePipe },
    { type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_4__.NativeGeocoder },
    { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__.Geolocation },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__.Camera },
    { type: _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__.PhotoViewer },
    { type: _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_8__.Base64 },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.DomSanitizer }
];
WorkexpenseEditPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.Component)({
        selector: 'app-workexpense-edit',
        template: _raw_loader_workexpense_edit_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_workexpense_edit_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], WorkexpenseEditPage);



/***/ }),

/***/ 85124:
/*!*************************************************************!*\
  !*** ./src/app/workexpense-edit/workexpense-edit.page.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ3b3JrZXhwZW5zZS1lZGl0LnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 87263:
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/workexpense-edit/workexpense-edit.page.html ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">Expense Edit</ion-title>\n  </ion-toolbar>\n</ion-header> \n<ion-content>\n\n<ion-content>\n<form (ngSubmit)=\"register(form)\">\n    <ion-grid>\n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <!-- <div text-center>\n            <h3>Create your account!</h3>\n          </div> -->\n          <div padding>\n            <ion-item>\n    \n              <ion-label position=\"stacked\">Project</ion-label>\n                  <ion-select interface=\"popover\" placeholder={{project_text}} [(ngModel)]=\"project\" [ngModelOptions]=\"{standalone: true}\">\n                    <ion-select-option *ngFor=\"let val of projecy_list; let i = index\" value=\"{{val.sub_project_id}}\">{{val.project_id}} > {{val.sub_project_id}}</ion-select-option>\n                  </ion-select>\n                </ion-item> \n                <ion-item>\n                  \n              <ion-label position=\"stacked\">Expense category</ion-label>\n              <ion-select #C (ionChange)=\"selectChange(C.value)\" interface=\"popover\" placeholder={{category_text}} [(ngModel)]=\"category\" [ngModelOptions]=\"{standalone: true}\">\n                <ion-select-option *ngFor=\"let val of category_list; let i = index\" value=\"{{val.ec_ID}}\">{{val.ec_name}}</ion-select-option>\n                 \n              </ion-select>\n                </ion-item> \n              \n                <ion-item >\n                  \n                  <ion-label position=\"stacked\">Type</ion-label>\n                  <ion-select  interface=\"popover\" placeholder={{subcategory_text}} [(ngModel)]=\"subcategory\" [ngModelOptions]=\"{standalone: true}\">\n                    <ion-select-option *ngFor=\"let val of subcategory_list; let i = index\" value=\"{{val.ec_ID}}\">{{val.ec_name}}</ion-select-option>\n                     \n                  </ion-select>\n                    </ion-item>\n\n  <ion-item>\n  <ion-label position=\"floating\">Description</ion-label>\n  <ion-textarea placeholder=\"Enter more information here...\" [(ngModel)]=\"work_description\" [ngModelOptions]=\"{standalone: true}\"></ion-textarea>\n</ion-item>\n<ion-item>\n  <ion-label position=\"floating\">Amount</ion-label>\n  <ion-input type=\"number\" maxlength=\"10\" [(ngModel)]=\"expense_amount\" [ngModelOptions]=\"{standalone: true}\"></ion-input>\n</ion-item>\n<!-- <ion-item>\n      <ion-label position=\"stacked\">Image</ion-label>\n      <ion-input type=\"file\" accept=\"image/*\" id=\"upload\"  (ionChange)=\"imageFilePath_change($event)\"></ion-input>\n    </ion-item> -->\n     <ion-row>\n      <ion-col size=\"10\">\n      <div *ngIf=\"isToggled == false\">\n      <ion-button color=\"primary\"  (click)=\"deposit_slip_image()\" expand=\"block\">\n        <ion-icon name=\"camera\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n      </div>\n    </ion-col>\n    <ion-col size=\"2\">\n      <div class=\"image_border\" *ngIf=\"depositImage\">\n      <img [src]=\"sanitizer.bypassSecurityTrustUrl(depositImage)\" (click)=\"imageViewer(depositImage)\">\n      </div>\n    </ion-col>\n    \n    </ion-row>\n   <ion-item>\n      <ion-label position=\"stacked\" style=\"position: relative;\">Location </ion-label>\n      <!-- <div style=\"position: absolute;right: 15px;top: 6px;\"><span (click)=\"getLocation()\" style=\"font-size: 25px;\"><ion-icon name=\"refresh-circle-outline\"></ion-icon></span></div> -->\n      <div *ngIf=\"address==''\"></div>\n      <div *ngIf=\"address\">{{address}}</div>\n    </ion-item>\n\n<br>\n\n\n          </div>\n          <div padding>\n            <ion-button  size=\"large\" (click)=\"submit_mode()\"  expand=\"block\">Save</ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_workexpense-edit_workexpense-edit_module_ts.js.map